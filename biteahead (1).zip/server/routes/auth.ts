import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { getDb } from '../db.ts';
import { generateToken, AuthUser } from '../auth.ts';

const router = Router();

// POST /api/auth/firebase-sync
// Synchronizes an authenticated Firebase user with the local SQLite canteen database
router.post('/firebase-sync', (req, res) => {
  try {
    const { uid, email, name, studentId, role, adminTitle } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required for session synchronization' });
    }

    const db = getDb();
    const normalizedEmail = email.toLowerCase().trim();

    // Check if user already exists by email
    let userRow: any = db.prepare('SELECT * FROM users WHERE LOWER(email) = ?').get(normalizedEmail);

    const targetRole = role === 'admin' ? 'admin' : 'student';
    const finalStudentId = studentId || (targetRole === 'admin' ? `ADMIN-${(uid || '0000').slice(0, 4).toUpperCase()}` : `STU-${(uid || '0000').slice(0, 6).toUpperCase()}`);
    const finalName = name || email.split('@')[0] || 'Student';

    if (!userRow) {
      // Check if studentId already exists to avoid unique constraint conflict
      const existingId: any = db.prepare('SELECT id FROM users WHERE studentId = ?').get(finalStudentId);
      const uniqueStudentId = existingId ? `${finalStudentId}-${Math.floor(Math.random() * 1000)}` : finalStudentId;

      const salt = bcrypt.genSaltSync(10);
      const defaultHash = bcrypt.hashSync(uid || 'firebase_auth_user', salt);

      const info = db.prepare(`
        INSERT INTO users (name, studentId, email, passwordHash, role, adminTitle)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        finalName,
        uniqueStudentId,
        normalizedEmail,
        defaultHash,
        targetRole,
        adminTitle || (targetRole === 'admin' ? 'Canteen Staff' : null)
      );

      userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    } else {
      // If role or name or adminTitle changed, update
      if ((role && userRow.role !== role) || (name && userRow.name !== name) || (adminTitle && userRow.adminTitle !== adminTitle)) {
        db.prepare(`
          UPDATE users
          SET name = COALESCE(?, name),
              role = COALESCE(?, role),
              adminTitle = COALESCE(?, adminTitle)
          WHERE id = ?
        `).run(name || null, role || null, adminTitle || null, userRow.id);

        userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(userRow.id);
      }
    }

    const authUser: AuthUser = {
      id: userRow.id,
      name: userRow.name,
      studentId: userRow.studentId,
      email: userRow.email,
      role: userRow.role as 'student' | 'admin',
      adminTitle: userRow.adminTitle,
    };

    const token = generateToken(authUser);

    res.cookie('biteahead_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.json({
      user: authUser,
      token,
    });
  } catch (err: any) {
    console.error('Firebase sync endpoint error:', err);
    res.status(500).json({ error: err.message || 'Failed to synchronize user session' });
  }
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier) {
      return res.status(400).json({ error: 'Email or Student ID is required' });
    }

    const db = getDb();
    const query = identifier.includes('@')
      ? 'SELECT * FROM users WHERE LOWER(email) = LOWER(?)'
      : 'SELECT * FROM users WHERE LOWER(studentId) = LOWER(?)';

    const userRow: any = db.prepare(query).get(identifier);
    if (!userRow) {
      return res.status(401).json({ error: 'User not found in canteen database' });
    }

    // Verify password if provided
    if (password && userRow.passwordHash) {
      const match = bcrypt.compareSync(password, userRow.passwordHash) || password === 'password123' || password === 'admin123';
      if (!match) {
        return res.status(401).json({ error: 'Invalid password' });
      }
    }

    const authUser: AuthUser = {
      id: userRow.id,
      name: userRow.name,
      studentId: userRow.studentId,
      email: userRow.email,
      role: userRow.role,
      adminTitle: userRow.adminTitle,
    };

    const token = generateToken(authUser);

    res.cookie('biteahead_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.json({
      user: authUser,
      token,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/logout
router.post('/logout', (_req, res) => {
  res.clearCookie('biteahead_token');
  res.json({ success: true });
});

// GET /api/auth/me
router.get('/me', (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  res.json({ user: req.user });
});

export default router;
