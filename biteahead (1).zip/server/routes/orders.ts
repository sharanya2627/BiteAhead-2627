import { Router } from 'express';
import { getDb } from '../db.ts';
import { requireAuth, requireAdmin } from '../auth.ts';

const router = Router();

// GET /api/orders/pickup-slots
router.get('/pickup-slots', (_req, res) => {
  try {
    const db = getDb();
    const slots = db.prepare('SELECT * FROM pickup_slots WHERE isEnabled = 1 ORDER BY id ASC').all();
    res.json({ slots });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/orders
router.post('/', requireAuth, (req, res) => {
  try {
    const db = getDb();
    const { items, pickupSlot, notes } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Order must contain at least one item' });
    }

    if (!pickupSlot) {
      return res.status(400).json({ error: 'Pickup break slot must be selected' });
    }

    // Verify all items from database & calculate authoritative total price
    let calculatedTotal = 0;
    let maxPrepTime = 0;
    const verifiedItems: Array<{ foodItemId: number; quantity: number; price: number; name: string }> = [];

    for (const item of items) {
      const foodId = item.foodItemId || item.food?.id || item.id;
      const quantity = Math.max(1, parseInt(item.quantity) || 1);

      const foodRow: any = db.prepare('SELECT * FROM food_items WHERE id = ?').get(foodId);
      if (!foodRow) {
        return res.status(400).json({ error: `Food item #${foodId} is no longer valid` });
      }

      if (foodRow.isAvailable !== 1) {
        return res.status(400).json({ error: `"${foodRow.name}" is currently marked as sold out` });
      }

      calculatedTotal += foodRow.price * quantity;
      if (foodRow.preparationTime > maxPrepTime) {
        maxPrepTime = foodRow.preparationTime;
      }

      verifiedItems.push({
        foodItemId: foodRow.id,
        quantity,
        price: foodRow.price,
        name: foodRow.name,
      });
    }

    // Generate unique college canteen order ID
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const orderId = `BA-${randomSuffix}`;

    const studentId = req.user!.id;

    const orderInsert = db.prepare(`
      INSERT INTO orders (orderId, studentId, totalAmount, pickupSlot, status, notes, estimatedPrepTime)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      orderId,
      studentId,
      calculatedTotal,
      pickupSlot,
      'Placed',
      notes?.trim() || null,
      maxPrepTime || 10
    );

    const insertedOrderId = orderInsert.lastInsertRowid;

    // Insert order items
    const insertItemStmt = db.prepare(`
      INSERT INTO order_items (orderId, foodItemId, quantity, priceAtOrderTime)
      VALUES (?, ?, ?, ?)
    `);

    for (const vItem of verifiedItems) {
      insertItemStmt.run(insertedOrderId, vItem.foodItemId, vItem.quantity, vItem.price);
    }

    // Fetch complete newly created order
    const orderData: any = db.prepare(`
      SELECT o.*, u.name as studentName, u.studentId as collegeStudentId, u.email as studentEmail
      FROM orders o
      JOIN users u ON o.studentId = u.id
      WHERE o.id = ?
    `).get(insertedOrderId);

    orderData.items = verifiedItems.map(i => ({
      foodItemId: i.foodItemId,
      name: i.name,
      quantity: i.quantity,
      priceAtOrderTime: i.price,
    }));

    res.status(201).json({ order: orderData });
  } catch (err: any) {
    console.error('Order creation error:', err);
    res.status(500).json({ error: err.message || 'Failed to place order' });
  }
});

// GET /api/orders
router.get('/', requireAuth, (req, res) => {
  try {
    const db = getDb();
    const isStudent = req.user!.role === 'student';

    let ordersQuery = `
      SELECT o.*, u.name as studentName, u.studentId as collegeStudentId, u.email as studentEmail,
             ha.name as handlingAdminName, ha.adminTitle as handlingAdminTitle
      FROM orders o
      JOIN users u ON o.studentId = u.id
      LEFT JOIN users ha ON o.handlingAdminId = ha.id
    `;

    if (isStudent) {
      ordersQuery += ' WHERE o.studentId = ?';
    }

    ordersQuery += ' ORDER BY o.id DESC';

    const orders: any[] = isStudent
      ? db.prepare(ordersQuery).all(req.user!.id)
      : db.prepare(ordersQuery).all();

    for (const o of orders) {
      o.items = db.prepare(`
        SELECT oi.*, fi.name, fi.category, fi.image, fi.preparationTime
        FROM order_items oi
        JOIN food_items fi ON oi.foodItemId = fi.id
        WHERE oi.orderId = ?
      `).all(o.id);
    }

    res.json({ orders });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/orders/:id/status
router.put('/:id/status', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const orderIdentifier = req.params.id;
    const { status } = req.body;

    const validStatuses = ['Placed', 'Accepted', 'Preparing', 'Ready for Pickup', 'Completed', 'Cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid order status' });
    }

    const orderRow: any = db.prepare(`
      SELECT * FROM orders WHERE orderId = ? OR id = ?
    `).get(orderIdentifier, orderIdentifier);

    if (!orderRow) {
      return res.status(404).json({ error: 'Order not found' });
    }

    db.prepare(`
      UPDATE orders
      SET status = ?, handlingAdminId = ?, updatedAt = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(status, req.user!.id, orderRow.id);

    // Audit log
    db.prepare(`
      INSERT INTO admin_actions (adminId, adminName, action, targetType, targetId, details)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      req.user!.id,
      req.user!.name,
      `STATUS_${status.toUpperCase().replace(/\s+/g, '_')}`,
      'Order',
      orderRow.orderId,
      `Changed order status from ${orderRow.status} to ${status}`
    );

    res.json({ success: true, orderId: orderRow.orderId, status });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
