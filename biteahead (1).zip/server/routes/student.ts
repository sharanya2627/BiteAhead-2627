import { Router } from 'express';
import { getDb } from '../db.ts';
import { requireAuth } from '../auth.ts';

const router = Router();

// GET /api/student/orders
router.get('/orders', requireAuth, (req, res) => {
  try {
    const db = getDb();
    const studentId = req.user!.id;

    const orders: any[] = db.prepare(`
      SELECT o.*, u.name as studentName, u.studentId as collegeStudentId, u.email as studentEmail,
             ha.name as handlingAdminName, ha.adminTitle as handlingAdminTitle
      FROM orders o
      JOIN users u ON o.studentId = u.id
      LEFT JOIN users ha ON o.handlingAdminId = ha.id
      WHERE o.studentId = ?
      ORDER BY o.id DESC
    `).all(studentId);

    for (const o of orders) {
      o.items = db.prepare(`
        SELECT oi.*, fi.name, fi.category, fi.image, fi.preparationTime
        FROM order_items oi
        JOIN food_items fi ON oi.foodItemId = fi.id
        WHERE oi.orderId = ?
      `).all(o.id);
    }

    res.json({ orders });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/student/profile
router.get('/profile', requireAuth, (req, res) => {
  try {
    const db = getDb();
    const studentId = req.user!.id;

    const stats: any = db.prepare(`
      SELECT COUNT(*) as totalOrders, COALESCE(SUM(totalAmount), 0) as totalSpent
      FROM orders
      WHERE studentId = ? AND status != 'Cancelled'
    `).get(studentId);

    res.json({
      profile: req.user,
      stats: {
        totalOrders: stats.totalOrders || 0,
        totalSpent: Math.round((stats.totalSpent || 0) * 100) / 100,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
