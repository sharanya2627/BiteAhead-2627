import { Router } from 'express';
import { getDb } from '../db.ts';
import { requireAdmin } from '../auth.ts';

const router = Router();

// GET /api/foods
router.get('/', (req, res) => {
  try {
    const db = getDb();
    const { category, availableOnly } = req.query;

    let sql = 'SELECT * FROM food_items WHERE 1=1';
    const params: any[] = [];

    if (category && category !== 'All') {
      sql += ' AND category = ?';
      params.push(category);
    }

    if (availableOnly === 'true') {
      sql += ' AND isAvailable = 1';
    }

    sql += ' ORDER BY id ASC';

    const items = db.prepare(sql).all(...params);
    res.json({ items, foods: items });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/foods/:id
router.get('/:id', (req, res) => {
  try {
    const db = getDb();
    const item = db.prepare('SELECT * FROM food_items WHERE id = ?').get(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Food item not found' });
    }
    res.json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/foods
router.post('/', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const { name, description, category, price, preparationTime, image, isAvailable } = req.body;

    if (!name || price === undefined || preparationTime === undefined) {
      return res.status(400).json({ error: 'Name, price, and preparation time are required' });
    }

    const info = db.prepare(`
      INSERT INTO food_items (name, description, category, price, preparationTime, image, isAvailable, createdBy)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      name,
      description || '',
      category || 'Fast Food',
      Number(price),
      Number(preparationTime),
      image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80',
      isAvailable ? 1 : 0,
      req.user?.id || 1
    );

    const newItem: any = db.prepare('SELECT * FROM food_items WHERE id = ?').get(info.lastInsertRowid);

    // Audit log
    db.prepare(`
      INSERT INTO admin_actions (adminId, adminName, action, targetType, targetId, details)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      req.user?.id || 1,
      req.user?.name || 'Admin',
      'ADD_MENU_ITEM',
      'FoodItem',
      String(newItem.id),
      `Added item "${newItem.name}" at ₹${newItem.price}`
    );

    res.status(201).json(newItem);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/foods/:id
router.put('/:id', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const id = req.params.id;
    const { name, description, category, price, preparationTime, image, isAvailable } = req.body;

    db.prepare(`
      UPDATE food_items
      SET name = ?, description = ?, category = ?, price = ?, preparationTime = ?, image = ?, isAvailable = ?, updatedAt = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      name,
      description || '',
      category || 'Fast Food',
      Number(price),
      Number(preparationTime),
      image || '',
      isAvailable ? 1 : 0,
      id
    );

    const updatedItem: any = db.prepare('SELECT * FROM food_items WHERE id = ?').get(id);

    // Audit log
    db.prepare(`
      INSERT INTO admin_actions (adminId, adminName, action, targetType, targetId, details)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      req.user?.id || 1,
      req.user?.name || 'Admin',
      'UPDATE_MENU_ITEM',
      'FoodItem',
      String(id),
      `Updated item "${name}" at ₹${price}`
    );

    res.json(updatedItem);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/foods/:id/availability
router.patch('/:id/availability', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const id = req.params.id;
    const item: any = db.prepare('SELECT * FROM food_items WHERE id = ?').get(id);
    if (!item) {
      return res.status(404).json({ error: 'Food item not found' });
    }

    const newAvail = item.isAvailable === 1 ? 0 : 1;
    db.prepare('UPDATE food_items SET isAvailable = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?').run(newAvail, id);

    // Audit log
    db.prepare(`
      INSERT INTO admin_actions (adminId, adminName, action, targetType, targetId, details)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      req.user?.id || 1,
      req.user?.name || 'Admin',
      'TOGGLE_AVAILABILITY',
      'FoodItem',
      String(id),
      `Set availability of "${item.name}" to ${newAvail === 1 ? 'AVAILABLE' : 'UNAVAILABLE'}`
    );

    res.json({ id: item.id, isAvailable: newAvail });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/foods/:id
router.delete('/:id', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const id = req.params.id;
    const item: any = db.prepare('SELECT * FROM food_items WHERE id = ?').get(id);

    db.prepare('DELETE FROM food_items WHERE id = ?').run(id);

    if (item) {
      db.prepare(`
        INSERT INTO admin_actions (adminId, adminName, action, targetType, targetId, details)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        req.user?.id || 1,
        req.user?.name || 'Admin',
        'DELETE_MENU_ITEM',
        'FoodItem',
        String(id),
        `Deleted item "${item.name}"`
      );
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
