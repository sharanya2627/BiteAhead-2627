import { Router } from 'express';
import { getDb } from '../db.ts';
import { requireAdmin } from '../auth.ts';

const router = Router();

// GET /api/admin/dashboard
router.get('/dashboard', requireAdmin, (_req, res) => {
  try {
    const db = getDb();

    const counts: any = db.prepare(`
      SELECT
        COUNT(*) as totalOrders,
        SUM(CASE WHEN status IN ('Placed', 'Accepted') THEN 1 ELSE 0 END) as pendingOrders,
        SUM(CASE WHEN status = 'Preparing' THEN 1 ELSE 0 END) as ordersPreparing,
        SUM(CASE WHEN status = 'Ready for Pickup' THEN 1 ELSE 0 END) as readyForPickup,
        SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completedOrders,
        COALESCE(SUM(CASE WHEN status != 'Cancelled' THEN totalAmount ELSE 0 END), 0) as todayRevenue
      FROM orders
    `).get();

    const metrics = {
      totalOrders: counts.totalOrders || 0,
      pendingOrders: counts.pendingOrders || 0,
      ordersPreparing: counts.ordersPreparing || 0,
      readyForPickup: counts.readyForPickup || 0,
      completedOrders: counts.completedOrders || 0,
      todayRevenue: Math.round((counts.todayRevenue || 0) * 100) / 100,
    };

    // Kitchen live preparation queue (active incomplete orders)
    const queue: any[] = db.prepare(`
      SELECT o.*, u.name as studentName, u.studentId as collegeStudentId, u.email as studentEmail,
             ha.name as handlingAdminName, ha.adminTitle as handlingAdminTitle
      FROM orders o
      JOIN users u ON o.studentId = u.id
      LEFT JOIN users ha ON o.handlingAdminId = ha.id
      WHERE o.status IN ('Placed', 'Accepted', 'Preparing', 'Ready for Pickup')
      ORDER BY
        CASE o.status
          WHEN 'Placed' THEN 1
          WHEN 'Accepted' THEN 2
          WHEN 'Preparing' THEN 3
          WHEN 'Ready for Pickup' THEN 4
          ELSE 5
        END,
        o.id ASC
    `).all();

    for (const q of queue) {
      q.items = db.prepare(`
        SELECT oi.*, fi.name, fi.category, fi.image, fi.preparationTime
        FROM order_items oi
        JOIN food_items fi ON oi.foodItemId = fi.id
        WHERE oi.orderId = ?
      `).all(q.id);
    }

    const recentActions = db.prepare(`
      SELECT * FROM admin_actions ORDER BY id DESC LIMIT 15
    `).all();

    res.json({
      metrics,
      preparationQueue: queue,
      recentActions,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/orders
router.get('/orders', requireAdmin, (_req, res) => {
  try {
    const db = getDb();
    const orders: any[] = db.prepare(`
      SELECT o.*, u.name as studentName, u.studentId as collegeStudentId, u.email as studentEmail,
             ha.name as handlingAdminName, ha.adminTitle as handlingAdminTitle
      FROM orders o
      JOIN users u ON o.studentId = u.id
      LEFT JOIN users ha ON o.handlingAdminId = ha.id
      ORDER BY o.id DESC
    `).all();

    for (const o of orders) {
      o.items = db.prepare(`
        SELECT oi.*, fi.name, fi.category, fi.image, fi.preparationTime
        FROM order_items oi
        JOIN food_items fi ON oi.foodItemId = fi.id
        WHERE oi.orderId = ?
      `).all(o.id);
    }

    res.json({ orders });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/menu
router.get('/menu', requireAdmin, (_req, res) => {
  try {
    const db = getDb();
    const items = db.prepare('SELECT * FROM food_items ORDER BY id ASC').all();
    res.json({ items, foods: items });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/actions
router.get('/actions', requireAdmin, (_req, res) => {
  try {
    const db = getDb();
    const actions = db.prepare('SELECT * FROM admin_actions ORDER BY id DESC LIMIT 50').all();
    res.json({ actions });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
