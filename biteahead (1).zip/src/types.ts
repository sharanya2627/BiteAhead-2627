export interface User {
  id: number;
  name: string;
  studentId: string;
  email: string;
  role: 'student' | 'admin';
  adminTitle?: string | null;
}

export type FoodCategory =
  | 'All'
  | 'Fast Food'
  | 'Brown Bear'
  | 'Meals'
  | 'Cocktail / Beverages'
  | 'Waffles';

export interface FoodItem {
  id: number;
  name: string;
  description: string;
  category: string;
  price: number;
  preparationTime: number;
  image: string;
  isAvailable: number;
  createdAt?: string;
  updatedAt?: string;
  createdByName?: string;
}

export interface CartItem {
  food: FoodItem;
  quantity: number;
}

export interface OrderItem {
  id?: number;
  foodItemId: number;
  quantity: number;
  priceAtOrderTime: number;
  name: string;
  category?: string;
  image?: string;
  preparationTime?: number;
}

export type OrderStatus =
  | 'Placed'
  | 'Accepted'
  | 'Preparing'
  | 'Ready for Pickup'
  | 'Completed'
  | 'Cancelled';

export interface Order {
  id: number;
  orderId: string;
  studentId: number;
  studentName?: string;
  collegeStudentId?: string;
  studentEmail?: string;
  totalAmount: number;
  pickupSlot: string;
  status: OrderStatus;
  notes?: string | null;
  handlingAdminId?: number | null;
  handlingAdminName?: string | null;
  handlingAdminTitle?: string | null;
  estimatedPrepTime?: number;
  createdAt: string;
  updatedAt: string;
  items?: OrderItem[];
}

export interface PickupSlot {
  id: number;
  slotTime: string;
  label: string;
  isEnabled: number;
  maxCapacity: number;
  createdAt?: string;
}

export interface AdminAction {
  id: number;
  adminId: number;
  adminName: string;
  adminTitle?: string | null;
  action: string;
  targetType: string;
  targetId: string;
  details?: string | null;
  timestamp: string;
}

export interface DashboardMetrics {
  totalOrders: number;
  pendingOrders: number;
  ordersPreparing: number;
  readyForPickup: number;
  completedOrders: number;
  todayRevenue: number;
}
