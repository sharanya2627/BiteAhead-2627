import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { CartProvider, useCart } from './context/CartContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { StudentDashboard } from './pages/StudentDashboard.tsx';
import { MenuPage } from './pages/MenuPage.tsx';
import { CartPage } from './pages/CartPage.tsx';
import { OrdersPage } from './pages/OrdersPage.tsx';
import { StudentProfilePage } from './pages/StudentProfilePage.tsx';
import { AdminDashboard } from './pages/AdminDashboard.tsx';
import { AdminOrdersPage } from './pages/AdminOrdersPage.tsx';
import { AdminMenuPage } from './pages/AdminMenuPage.tsx';
import { AdminAuditLogsPage } from './pages/AdminAuditLogsPage.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { seedInitialFirestoreData } from './lib/firebase.ts';
import { UtensilsCrossed, Sparkles } from 'lucide-react';

const MainContent: React.FC = () => {
  const { user, loading } = useAuth();
  const { totalItemCount } = useCart();
  const [currentTab, setCurrentTab] = useState<string>('student-dashboard');
  const [highlightOrderId, setHighlightOrderId] = useState<string | null>(null);

  // Seed default students and admins to Firestore on initialization
  React.useEffect(() => {
    seedInitialFirestoreData();
  }, []);

  // Sync initial tab when user logs in/out or changes role
  React.useEffect(() => {
    if (!loading) {
      if (user?.role === 'admin') {
        if (!currentTab.startsWith('admin-')) {
          setCurrentTab('admin-dashboard');
        }
      } else {
        if (currentTab.startsWith('admin-')) {
          setCurrentTab('student-dashboard');
        }
      }
    }
  }, [user?.role, loading]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center mx-auto animate-bounce shadow-lg shadow-amber-500/25">
            <UtensilsCrossed className="w-6 h-6" />
          </div>
          <div className="font-extrabold text-slate-800 text-lg">BiteAhead</div>
          <div className="text-xs text-slate-500 font-medium">Initializing Campus Canteen System...</div>
        </div>
      </div>
    );
  }

  const handleOrderPlaced = (orderId: string) => {
    setHighlightOrderId(orderId);
    setCurrentTab('orders');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-amber-500 selection:text-white">
      <Navbar currentTab={currentTab} setCurrentTab={setCurrentTab} />

      <main className="flex-1 pb-16">
        {(currentTab === 'login' || currentTab === 'signup') && (
          <LoginPage
            initialMode={currentTab === 'signup' ? 'signup' : 'signin'}
            onSuccess={() => {
              if (user?.role === 'admin') {
                setCurrentTab('admin-dashboard');
              } else if (totalItemCount > 0) {
                setCurrentTab('cart');
              } else {
                setCurrentTab('student-dashboard');
              }
            }}
          />
        )}

        {/* Student Views */}
        {currentTab === 'student-dashboard' && <StudentDashboard onNavigate={setCurrentTab} />}
        {currentTab === 'menu' && <MenuPage onNavigate={setCurrentTab} />}
        {currentTab === 'cart' && <CartPage onNavigate={setCurrentTab} onOrderPlaced={handleOrderPlaced} />}
        {currentTab === 'orders' && <OrdersPage onNavigate={setCurrentTab} highlightOrderId={highlightOrderId} />}
        {currentTab === 'profile' && <StudentProfilePage onNavigate={setCurrentTab} />}

        {/* Admin Views */}
        {currentTab === 'admin-dashboard' && <AdminDashboard onNavigate={setCurrentTab} />}
        {currentTab === 'admin-orders' && <AdminOrdersPage />}
        {currentTab === 'admin-menu' && <AdminMenuPage />}
        {currentTab === 'admin-actions' && <AdminAuditLogsPage />}
      </main>

      {/* College Canteen Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-900 tracking-tight">
              Bite<span className="text-amber-500">Ahead</span>
            </span>
            <span>•</span>
            <span>Order Before. Pick Up On Time.</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>College Canteen Pre-order System</span>
            <span>•</span>
            <span>Campus Dining Edition</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <MainContent />
      </CartProvider>
    </AuthProvider>
  );
}
