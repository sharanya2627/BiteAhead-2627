import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useCart } from '../context/CartContext.tsx';
import {
  UtensilsCrossed,
  LayoutDashboard,
  Layers,
  ChefHat,
  History,
  Clock,
  ShoppingBag,
  ShoppingCart,
  ShieldCheck,
  ChevronDown,
  User as UserIcon,
  LogOut,
  LogIn,
  UserPlus,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab }) => {
  const { user, firebaseUser, logout } = useAuth();
  const { totalItemCount, subtotal } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setCurrentTab(user?.role === 'admin' ? 'admin-dashboard' : 'student-dashboard')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold tracking-tight text-slate-900 group-hover:text-amber-600 transition-colors">
                  Bite<span className="text-amber-500">Ahead</span>
                </span>
                <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wide">
                  Canteen
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium -mt-0.5 hidden sm:block">
                Order Before. Pick Up On Time.
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {user?.role === 'admin' ? (
              <>
                <button
                  onClick={() => setCurrentTab('admin-dashboard')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'admin-dashboard'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Live Kitchen Queue
                </button>
                <button
                  onClick={() => setCurrentTab('admin-orders')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'admin-orders'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  All Orders
                </button>
                <button
                  onClick={() => setCurrentTab('admin-menu')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'admin-menu'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <ChefHat className="w-4 h-4" />
                  Menu Management
                </button>
                <button
                  onClick={() => setCurrentTab('admin-actions')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'admin-actions'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <History className="w-4 h-4" />
                  Audit Trail
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setCurrentTab('student-dashboard')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'student-dashboard'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </button>
                <button
                  onClick={() => setCurrentTab('menu')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'menu'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <UtensilsCrossed className="w-4 h-4" />
                  Canteen Menu
                </button>
                <button
                  onClick={() => setCurrentTab('orders')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                    currentTab === 'orders'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  My Orders
                </button>
              </>
            )}
          </nav>

          {/* Right Area: Cart + User Profile / Login */}
          <div className="flex items-center gap-3">
            {user?.role !== 'admin' && (
              <button
                onClick={() => setCurrentTab('cart')}
                className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all border font-semibold text-sm cursor-pointer ${
                  currentTab === 'cart'
                    ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-200'
                }`}
              >
                <ShoppingCart className="w-4 h-4" />
                <span className="hidden sm:inline">Break Cart</span>
                {totalItemCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full text-xs font-bold bg-amber-600 text-white animate-bounce">
                    {totalItemCount}
                  </span>
                )}
                {subtotal > 0 && (
                  <span className="text-xs opacity-90 hidden sm:inline font-mono font-bold">
                    ₹{subtotal}
                  </span>
                )}
              </button>
            )}

            {user || firebaseUser ? (
              <div className="relative">
                <button
                  onClick={() => setMenuOpen(!menuOpen)}
                  className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                >
                  {firebaseUser?.photoURL ? (
                    <img
                      src={firebaseUser.photoURL}
                      alt={user?.name || 'User'}
                      className="w-8 h-8 rounded-full object-cover border border-slate-200 shadow-xs"
                    />
                  ) : (
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs ${
                        user?.role === 'admin'
                          ? 'bg-gradient-to-tr from-purple-600 to-indigo-600'
                          : 'bg-gradient-to-tr from-amber-500 to-orange-500'
                      }`}
                    >
                      {(user?.name || firebaseUser?.displayName || firebaseUser?.email || 'U')
                        .charAt(0)
                        .toUpperCase()}
                    </div>
                  )}
                  <div className="text-left hidden sm:block">
                    <div className="text-xs font-bold text-slate-800 leading-tight flex items-center gap-1">
                      {(user?.name || firebaseUser?.displayName || firebaseUser?.email?.split('@')[0] || 'User').split(' ')[0]}
                      {user?.role === 'admin' && <ShieldCheck className="w-3 h-3 text-purple-600" />}
                    </div>
                    <div className="text-[10px] text-slate-500 capitalize">
                      {user?.role === 'admin' ? user?.adminTitle || 'Admin' : user?.studentId || 'Student'}
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {menuOpen && (
                  <div
                    className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50"
                    onMouseLeave={() => setMenuOpen(false)}
                  >
                    <div className="px-4 py-2.5 border-b border-slate-100">
                      <div className="text-xs font-bold text-slate-900">
                        {user?.name || firebaseUser?.displayName || 'User'}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {user?.email || firebaseUser?.email}
                      </div>
                      <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 uppercase">
                        {user?.role || 'student'} • {user?.studentId || 'Active'}
                      </div>
                    </div>
                    {user?.role === 'student' && (
                      <button
                        onClick={() => {
                          setCurrentTab('profile');
                          setMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                      >
                        <UserIcon className="w-4 h-4 text-slate-400" />
                        My Student Profile
                      </button>
                    )}
                    <button
                      onClick={() => {
                        logout();
                        setMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-medium border-t border-slate-100 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentTab('login')}
                  className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  Sign In
                </button>
                <button
                  onClick={() => setCurrentTab('signup')}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  Sign Up
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden border-t border-slate-100 bg-slate-50 px-2 py-2 flex items-center justify-around text-xs">
        {user?.role === 'admin' ? (
          <>
            <button
              onClick={() => setCurrentTab('admin-dashboard')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'admin-dashboard' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Kitchen Queue
            </button>
            <button
              onClick={() => setCurrentTab('admin-orders')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'admin-orders' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Orders
            </button>
            <button
              onClick={() => setCurrentTab('admin-menu')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'admin-menu' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Menu
            </button>
            <button
              onClick={() => setCurrentTab('admin-actions')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'admin-actions' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Logs
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => setCurrentTab('student-dashboard')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'student-dashboard' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentTab('menu')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'menu' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Menu
            </button>
            <button
              onClick={() => setCurrentTab('orders')}
              className={`px-3 py-1.5 rounded-lg font-semibold ${
                currentTab === 'orders' ? 'bg-amber-500 text-white' : 'text-slate-600'
              }`}
            >
              Orders
            </button>
          </>
        )}
      </div>
    </header>
  );
};
