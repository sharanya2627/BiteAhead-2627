import React from 'react';
import { OrderStatus } from '../types.ts';
import { CheckCircle2, Clock, ChefHat, PackageCheck, Hourglass, XCircle } from 'lucide-react';

interface OrderStatusBarProps {
  status: OrderStatus;
  orderId?: string;
  pickupSlot?: string;
  handlingAdminName?: string | null;
  handlingAdminTitle?: string | null;
}

const STAGES: Array<{
  key: OrderStatus;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { key: 'Placed', label: 'Placed', icon: Clock },
  { key: 'Accepted', label: 'Accepted', icon: CheckCircle2 },
  { key: 'Preparing', label: 'Cooking', icon: ChefHat },
  { key: 'Ready for Pickup', label: 'Ready', icon: PackageCheck },
  { key: 'Completed', label: 'Collected', icon: CheckCircle2 },
];

export const OrderStatusBar: React.FC<OrderStatusBarProps> = ({
  status,
  handlingAdminName,
  handlingAdminTitle,
}) => {
  if (status === 'Cancelled') {
    return (
      <div className="p-3 bg-rose-50 rounded-2xl border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
        <span>This pre-order was cancelled.</span>
      </div>
    );
  }

  const currentIndex = STAGES.findIndex(s => s.key === status);

  return (
    <div className="space-y-3">
      {/* Step Indicators */}
      <div className="grid grid-cols-5 gap-1 relative">
        {STAGES.map((stage, idx) => {
          const isDone = idx <= currentIndex;
          const isCurrent = idx === currentIndex;
          const Icon = stage.icon;

          return (
            <div key={stage.key} className="flex flex-col items-center text-center">
              <div
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all ${
                  isCurrent
                    ? 'bg-amber-500 text-white ring-4 ring-amber-400/20 scale-110 shadow-sm'
                    : isDone
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </div>
              <span
                className={`text-[10px] mt-1.5 font-bold truncate max-w-full ${
                  isCurrent
                    ? 'text-amber-600 font-extrabold'
                    : isDone
                    ? 'text-emerald-700'
                    : 'text-slate-400'
                }`}
              >
                {stage.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Handling Staff Attribution */}
      {handlingAdminName && (
        <div className="text-[11px] text-slate-500 flex items-center justify-end gap-1.5 pt-1">
          <ChefHat className="w-3.5 h-3.5 text-purple-600" />
          <span>
            Managed by <strong>{handlingAdminName}</strong> ({handlingAdminTitle || 'Canteen Staff'})
          </span>
        </div>
      )}
    </div>
  );
};
