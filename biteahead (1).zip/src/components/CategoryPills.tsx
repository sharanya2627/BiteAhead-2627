import React from 'react';
import { FoodCategory } from '../types.ts';

interface CategoryPillsProps {
  selectedCategory: FoodCategory;
  onSelectCategory: (category: FoodCategory) => void;
  counts?: Record<string, number>;
}

export const CATEGORIES: Array<{
  name: FoodCategory;
  icon: string;
  badge: string;
}> = [
  { name: 'All', icon: '🍽️', badge: 'All Items' },
  { name: 'Fast Food', icon: '🍜', badge: 'Noodles, Fried Rice & Manchurian' },
  { name: 'Brown Bear', icon: '🍞', badge: 'Bakery, Burgers & Puffs' },
  { name: 'Meals', icon: '🍛', badge: 'Mess, Rice, Chapatis & Curries' },
  { name: 'Cocktail / Beverages', icon: '🥤', badge: 'Chilled Coolers & Sodas' },
  { name: 'Waffles', icon: '🧇', badge: 'Belgian, Nutella & Oreo' },
];

export const CategoryPills: React.FC<CategoryPillsProps> = ({
  selectedCategory,
  onSelectCategory,
  counts = {},
}) => {
  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none py-1">
      {CATEGORIES.map(cat => {
        const isSelected = selectedCategory === cat.name;
        const count = cat.name === 'All' ? Object.values(counts).reduce((a, b) => a + b, 0) : counts[cat.name];

        return (
          <button
            key={cat.name}
            onClick={() => onSelectCategory(cat.name)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs whitespace-nowrap transition-all duration-200 border ${
              isSelected
                ? 'bg-amber-500 text-white border-amber-600 shadow-md shadow-amber-500/20 scale-[1.02]'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            <span className="text-base">{cat.icon}</span>
            <span>{cat.name}</span>
            {count !== undefined && count > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                  isSelected ? 'bg-amber-700/50 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};
