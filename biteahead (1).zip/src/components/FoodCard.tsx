import React from 'react';
import { FoodItem } from '../types.ts';
import { useCart } from '../context/CartContext.tsx';
import { Clock, Plus, Check } from 'lucide-react';

interface FoodCardProps {
  food: FoodItem;
}

export const FoodCard: React.FC<FoodCardProps> = ({ food }) => {
  const { cart, addToCart } = useCart();
  const cartItem = cart.find(c => c.food.id === food.id);
  const isAvailable = food.isAvailable === 1;

  return (
    <div
      className={`group bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between ${
        !isAvailable ? 'opacity-60 bg-slate-50' : ''
      }`}
    >
      <div>
        {/* Food Image with Category Badge & Availability Tag */}
        <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
          <img
            src={food.image}
            alt={food.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
          <div className="absolute top-3 left-3 flex items-center gap-1.5">
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-900/80 backdrop-blur-md text-white shadow-xs">
              {food.category}
            </span>
          </div>

          {!isAvailable && (
            <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center">
              <span className="px-3 py-1 rounded-full bg-rose-600 text-white font-extrabold text-xs uppercase tracking-wider shadow-md">
                Sold Out
              </span>
            </div>
          )}
        </div>

        {/* Details */}
        <div className="p-4 sm:p-5 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-extrabold text-slate-900 text-sm group-hover:text-amber-600 transition-colors line-clamp-1">
              {food.name}
            </h3>
            <span className="text-[11px] font-mono text-slate-500 shrink-0 flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-400" />
              {food.preparationTime}m
            </span>
          </div>

          <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
            {food.description}
          </p>
        </div>
      </div>

      {/* Footer Price & Add Button */}
      <div className="p-4 sm:p-5 pt-0 flex items-center justify-between gap-3 border-t border-slate-100 mt-2">
        <div>
          <div className="text-[10px] text-slate-400 uppercase font-semibold">Price</div>
          <div className="font-mono font-extrabold text-base text-slate-900">
            ₹{food.price}
          </div>
        </div>

        <button
          onClick={() => addToCart(food)}
          disabled={!isAvailable}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
            !isAvailable
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
              : cartItem
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
              : 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-amber-500/20 hover:scale-[1.02]'
          }`}
        >
          {cartItem ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>Added ({cartItem.quantity})</span>
            </>
          ) : (
            <>
              <Plus className="w-3.5 h-3.5" />
              <span>Add to Cart</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
