import React, { useState, useEffect } from 'react';
import { Order } from '../types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { apiFetch } from '../lib/api.ts';
import { getStudentOrdersFromFirestore, auth } from '../lib/firebase.ts';
import { OrderStatusBar } from '../components/OrderStatusBar.tsx';
import { Package, RefreshCw, ShoppingBag, ArrowRight, LogIn } from 'lucide-react';

interface OrdersPageProps {
  onNavigate: (tab: string) => void;
  highlightOrderId?: string | null;
}

export const OrdersPage: React.FC<OrdersPageProps> = ({ onNavigate, highlightOrderId }) => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = async () => {
    if (!user) {
      setOrders([]);
      setLoading(false);
      return;
    }
    try {
      setRefreshing(true);
      setError(null);
      // Try backend Express first if running
      const res = await apiFetch<{ orders: Order[] }>('/api/student/orders');
      if (res.orders && res.orders.length > 0) {
        setOrders(res.orders);
        return;
      }
    } catch (err: any) {
      console.log('Backend /api/student/orders unavailable, reading directly from Firebase Firestore:', err?.message);
    }

    // Direct Firestore fetch
    try {
      const fbOrders = await getStudentOrdersFromFirestore(user.email || user.studentId || '');
      if (fbOrders && fbOrders.length > 0) {
        setOrders(fbOrders as Order[]);
        setError(null);
      } else if (orders.length === 0) {
        setOrders([]);
      }
    } catch (fbErr: any) {
      console.warn('Firestore orders fetch notice:', fbErr?.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    if (user) {
      const interval = setInterval(fetchOrders, 6000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const activeOrders = orders.filter(
    o => o.status === 'Placed' || o.status === 'Accepted' || o.status === 'Preparing' || o.status === 'Ready for Pickup'
  );
  const pastOrders = orders.filter(o => o.status === 'Completed' || o.status === 'Cancelled');

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Title & Refresh */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-500" />
            My Canteen Pre-Orders
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track preparation progress in real-time. Pick up at the counter once status shows Ready!
          </p>
        </div>

        <button
          onClick={fetchOrders}
          disabled={refreshing}
          className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-xs flex items-center gap-2 transition-all shadow-xs cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-amber-500' : ''}`} />
          {refreshing ? 'Syncing...' : 'Live Status Refresh'}
        </button>
      </div>

      {user ? (
        loading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, idx) => (
              <div key={idx} className="bg-white rounded-3xl p-6 border border-slate-200 animate-pulse space-y-4">
                <div className="h-6 bg-slate-200 rounded-md w-1/4" />
                <div className="h-16 bg-slate-100 rounded-2xl" />
                <div className="h-4 bg-slate-200 rounded-md w-1/2" />
              </div>
            ))}
          </div>
        ) : orders.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
            <ShoppingBag className="w-12 h-12 text-slate-400 mx-auto" />
            <h3 className="font-bold text-slate-800 text-base">No pre-orders yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Ready to beat the queue? Explore the canteen menu and order your break meal right now.
            </p>
            <button
              onClick={() => onNavigate('menu')}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 cursor-pointer"
            >
              Open Canteen Menu
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Active Orders */}
            {activeOrders.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  <h2 className="text-lg font-extrabold text-slate-900">
                    Active Break Pre-Orders ({activeOrders.length})
                  </h2>
                </div>

                <div className="space-y-6">
                  {activeOrders.map(order => {
                    const isHighlighted = order.orderId === highlightOrderId;
                    return (
                      <div
                        key={order.id}
                        className={`bg-white rounded-3xl p-6 border-2 transition-all shadow-md space-y-5 ${
                          isHighlighted
                            ? 'border-amber-500 ring-4 ring-amber-500/10'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-extrabold text-lg text-slate-900">
                                {order.orderId}
                              </span>
                              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 font-mono">
                                {order.status}
                              </span>
                            </div>
                            <div className="text-xs text-slate-500 mt-1 flex items-center gap-3">
                              <span>
                                Pickup Slot: <strong className="text-slate-800">{order.pickupSlot}</strong>
                              </span>
                              <span>•</span>
                              <span>
                                {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="font-mono font-extrabold text-base text-slate-900">
                              ₹{order.totalAmount}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              Est. Prep: {order.estimatedPrepTime || 10} min
                            </div>
                          </div>
                        </div>

                        <OrderStatusBar
                          status={order.status}
                          orderId={order.orderId}
                          pickupSlot={order.pickupSlot}
                          handlingAdminName={order.handlingAdminName}
                          handlingAdminTitle={order.handlingAdminTitle}
                        />

                        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                          <div className="text-xs font-bold text-slate-700 mb-2">Order Items:</div>
                          <div className="divide-y divide-slate-200/60">
                            {order.items?.map((item, idx) => (
                              <div key={idx} className="py-2 flex items-center justify-between text-xs">
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-bold text-amber-600 w-6">
                                    {item.quantity}x
                                  </span>
                                  <span className="font-medium text-slate-800">{item.name}</span>
                                  {item.category && (
                                    <span className="text-[10px] text-slate-400 font-medium">
                                      ({item.category})
                                    </span>
                                  )}
                                </div>
                                <span className="font-mono font-bold text-slate-700">
                                  ₹{item.priceAtOrderTime * item.quantity}
                                </span>
                              </div>
                            ))}
                          </div>
                          {order.notes && (
                            <div className="mt-2 pt-2 border-t border-slate-200 text-[11px] text-slate-500 italic">
                              Kitchen Note: "{order.notes}"
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Past Orders */}
            {pastOrders.length > 0 && (
              <div className="space-y-4 pt-4">
                <h2 className="text-lg font-extrabold text-slate-800">Past Orders History</h2>
                <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden divide-y divide-slate-100 shadow-xs">
                  {pastOrders.map(order => (
                    <div
                      key={order.id}
                      className="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-sm text-slate-900">{order.orderId}</span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                              order.status === 'Completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {order.status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 mt-1">
                          {new Date(order.createdAt).toLocaleDateString()} at{' '}
                          {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}{' '}
                          • {order.pickupSlot}
                        </div>
                        <div className="text-xs text-slate-600 mt-1">
                          {order.items?.map(it => `${it.quantity}x ${it.name}`).join(', ')}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-mono font-extrabold text-sm text-slate-900">
                          ₹{order.totalAmount}
                        </div>
                        <button
                          onClick={() => onNavigate('menu')}
                          className="mt-1 text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
                        >
                          Order Again <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )
      ) : (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 mx-auto flex items-center justify-center font-bold">
            <LogIn className="w-7 h-7" />
          </div>
          <h3 className="font-extrabold text-slate-800 text-lg">Sign In to Track Orders</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Log in with your Student ID or select one of the demo student accounts to view your real-time pre-orders.
          </p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('login')}
              className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => onNavigate('signup')}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 cursor-pointer"
            >
              Sign Up
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
