import React, { useState, useEffect } from 'react';
import { DashboardMetrics, Order, AdminAction, OrderStatus } from '../types.ts';
import { apiFetch } from '../lib/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { updateOrderStatusInFirestore, getAllOrdersFromFirestore } from '../lib/firebase.ts';
import {
  LayoutDashboard,
  Clock,
  ChefHat,
  PackageCheck,
  CheckCircle2,
  TrendingUp,
  RefreshCw,
  AlertCircle,
  ArrowRight,
  Flame,
  ShieldCheck,
  UserCheck,
  Calendar,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [queue, setQueue] = useState<Order[]>([]);
  const [recentActions, setRecentActions] = useState<AdminAction[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const loadDashboard = async () => {
    try {
      try {
        const res = await apiFetch<{
          metrics: DashboardMetrics;
          preparationQueue: Order[];
          recentActions: AdminAction[];
        }>('/api/admin/dashboard');

        if (res?.metrics) {
          setMetrics(res.metrics);
          setQueue(res.preparationQueue || []);
          setRecentActions(res.recentActions || []);
          return;
        }
      } catch {}

      // Calculate directly from Firebase Firestore orders
      const fbOrders = await getAllOrdersFromFirestore();
      const activeQueue = fbOrders.filter(
        o => o.status === 'Placed' || o.status === 'Accepted' || o.status === 'Preparing' || o.status === 'Ready for Pickup'
      );
      const readyCount = fbOrders.filter(o => o.status === 'Ready for Pickup').length;
      const completedCount = fbOrders.filter(o => o.status === 'Completed').length;
      const totalRevenue = fbOrders
        .filter(o => o.status !== 'Cancelled')
        .reduce((sum, o) => sum + (o.totalAmount || 0), 0);

      const pendingCount = fbOrders.filter(o => o.status === 'Placed').length;
      const preparingCount = fbOrders.filter(o => o.status === 'Preparing' || o.status === 'Accepted').length;

      setMetrics({
        totalOrders: fbOrders.length,
        pendingOrders: pendingCount,
        ordersPreparing: preparingCount,
        readyForPickup: readyCount,
        completedOrders: completedCount,
        todayRevenue: totalRevenue,
      });
      setQueue(activeQueue as Order[]);
    } catch (err) {
      console.error('Failed to load admin dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
    // Auto-refresh the kitchen preparation queue every 6 seconds
    const interval = setInterval(loadDashboard, 6000);
    return () => clearInterval(interval);
  }, []);

  const handleUpdateStatus = async (orderId: string, nextStatus: OrderStatus) => {
    try {
      setUpdatingOrderId(orderId);

      // 1. Synchronize order status in Firebase Firestore first
      try {
        await updateOrderStatusInFirestore(orderId, nextStatus, user?.name, user?.adminTitle);
      } catch (fbErr: any) {
        console.error('🔥 [Firestore Status Update Error]:', fbErr?.message || fbErr);
      }

      // 2. Synchronize with backend if running
      try {
        await apiFetch(`/api/orders/${orderId}/status`, {
          method: 'PUT',
          body: JSON.stringify({ status: nextStatus }),
        });
      } catch {}

      setActionSuccess(`Order ${orderId} moved to "${nextStatus}"`);
      setTimeout(() => setActionSuccess(null), 3500);
      await loadDashboard();
    } catch (err: any) {
      console.warn('Error updating order:', err);
    } finally {
      setUpdatingOrderId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner & Active Admin Persona */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
              Admin Portal • {user?.adminTitle || 'Canteen Staff'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Kitchen Preparation & Dispatch Control
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Orders are prioritized by break pickup slot and order submission time to eliminate queues.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadDashboard}
            className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-2 transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            Refresh Queue
          </button>
          <button
            onClick={() => onNavigate('admin-menu')}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center gap-1.5"
          >
            <ChefHat className="w-4 h-4" />
            Manage Menu
          </button>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          {actionSuccess}
        </div>
      )}

      {/* Metrics Cards Grid (Section 11 Requirement) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Today's Orders</div>
          <div className="text-2xl font-extrabold font-mono text-slate-900 mt-1">
            {metrics?.totalOrders || 0}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Break Pre-orders</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-xs bg-amber-50/30">
          <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Pending Orders</div>
          <div className="text-2xl font-extrabold font-mono text-amber-900 mt-1">
            {metrics?.pendingOrders || 0}
          </div>
          <div className="text-[10px] text-amber-600 mt-1">Placed / Accepted</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-xs bg-blue-50/30">
          <div className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">Preparing</div>
          <div className="text-2xl font-extrabold font-mono text-blue-900 mt-1">
            {metrics?.ordersPreparing || 0}
          </div>
          <div className="text-[10px] text-blue-600 mt-1">In Wok / Oven</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-emerald-300 shadow-xs bg-emerald-50/40">
          <div className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Ready for Pickup</div>
          <div className="text-2xl font-extrabold font-mono text-emerald-900 mt-1">
            {metrics?.readyForPickup || 0}
          </div>
          <div className="text-[10px] text-emerald-600 mt-1">Awaiting Student</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-purple-200 shadow-xs bg-purple-50/30">
          <div className="text-[11px] font-bold text-purple-700 uppercase tracking-wider">Completed</div>
          <div className="text-2xl font-extrabold font-mono text-purple-900 mt-1">
            {metrics?.completedOrders || 0}
          </div>
          <div className="text-[10px] text-purple-600 mt-1">Picked Up</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-amber-300 shadow-xs bg-gradient-to-br from-amber-500/10 to-orange-500/10">
          <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">Today's Revenue</div>
          <div className="text-2xl font-extrabold font-mono text-amber-600 mt-1">
            ₹{metrics?.todayRevenue || 0}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Direct Sales</div>
        </div>
      </div>

      {/* PRIORITIZED KITCHEN PREPARATION QUEUE (Section 11 & 17 Requirement) */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-500" />
              Prioritized Kitchen Preparation Queue
            </h2>
            <p className="text-xs text-slate-500">
              Orders automatically sorted by: <strong>Pickup Time Slot → Order Time</strong> for synchronized cooking.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-lg">
            {queue.length} Active Orders in Queue
          </span>
        </div>

        {queue.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-2">
            <PackageCheck className="w-12 h-12 text-emerald-500 mx-auto" />
            <h3 className="font-bold text-slate-800 text-base">Kitchen Queue All Cleared!</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              All placed break orders have been prepared and collected. Waiting for upcoming break pre-orders.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {queue.map((order, index) => {
              const isUpdating = updatingOrderId === order.orderId;

              return (
                <div
                  key={order.id}
                  className={`bg-white rounded-3xl p-5 border-2 shadow-sm transition-all space-y-4 ${
                    order.status === 'Preparing'
                      ? 'border-blue-300 ring-2 ring-blue-100'
                      : order.status === 'Ready for Pickup'
                      ? 'border-emerald-400 bg-emerald-50/20'
                      : 'border-slate-200'
                  }`}
                >
                  {/* Top Bar with Queue Priority Number */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-900 text-amber-400 font-mono font-bold text-xs flex items-center justify-center">
                        #{index + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-extrabold text-base text-slate-900">
                            {order.orderId}
                          </span>
                          <span className="text-xs font-bold text-slate-600">
                            • {order.studentName} ({order.collegeStudentId})
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                          <span>
                            Target Slot: <strong className="text-amber-900 font-semibold">{order.pickupSlot}</strong>
                          </span>
                          <span>•</span>
                          <span>Ordered at {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold font-mono uppercase tracking-wider ${
                          order.status === 'Preparing'
                            ? 'bg-blue-100 text-blue-800'
                            : order.status === 'Ready for Pickup'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.status === 'Accepted'
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {order.status}
                      </span>
                      <span className="font-mono font-extrabold text-sm text-slate-900">
                        ₹{order.totalAmount}
                      </span>
                    </div>
                  </div>

                  {/* Items in this order */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {order.items?.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="w-6 h-6 rounded-md bg-amber-500 text-white font-mono font-bold text-xs flex items-center justify-center shrink-0">
                            {item.quantity}
                          </span>
                          <span className="font-bold text-slate-800 truncate">{item.name}</span>
                        </div>
                        <span className="font-mono text-slate-500 text-[11px] shrink-0">
                          {item.preparationTime}m prep
                        </span>
                      </div>
                    ))}
                  </div>

                  {order.notes && (
                    <div className="text-xs p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 font-medium">
                      Student Special Request: "{order.notes}"
                    </div>
                  )}

                  {/* Admin Action Buttons (Section 12 Requirement) */}
                  <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                      <ChefHat className="w-3.5 h-3.5 text-slate-400" />
                      Handled by:{' '}
                      <span className="font-semibold text-slate-700">
                        {order.handlingAdminName || 'Unassigned'}
                      </span>
                      {order.handlingAdminTitle && (
                        <span className="text-slate-400">({order.handlingAdminTitle})</span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {order.status === 'Placed' && (
                        <button
                          disabled={isUpdating}
                          onClick={() => handleUpdateStatus(order.orderId, 'Accepted')}
                          className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs transition-colors"
                        >
                          Accept Order
                        </button>
                      )}

                      {(order.status === 'Placed' || order.status === 'Accepted') && (
                        <button
                          disabled={isUpdating}
                          onClick={() => handleUpdateStatus(order.orderId, 'Preparing')}
                          className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1"
                        >
                          <ChefHat className="w-3.5 h-3.5" />
                          Start Preparing
                        </button>
                      )}

                      {order.status === 'Preparing' && (
                        <button
                          disabled={isUpdating}
                          onClick={() => handleUpdateStatus(order.orderId, 'Ready for Pickup')}
                          className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-colors flex items-center gap-1.5 animate-pulse"
                        >
                          <PackageCheck className="w-4 h-4" />
                          Mark Ready for Pickup
                        </button>
                      )}

                      {order.status === 'Ready for Pickup' && (
                        <button
                          disabled={isUpdating}
                          onClick={() => handleUpdateStatus(order.orderId, 'Completed')}
                          className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          Complete (Student Collected)
                        </button>
                      )}

                      <button
                        disabled={isUpdating}
                        onClick={() => {
                          if (confirm(`Cancel order ${order.orderId}?`)) {
                            handleUpdateStatus(order.orderId, 'Cancelled');
                          }
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-600 font-semibold text-xs transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent Admin Actions Audit Preview */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-purple-600" />
            <h3 className="font-extrabold text-slate-900 text-base">Recent Multi-Admin Audit Activity</h3>
          </div>
          <button
            onClick={() => onNavigate('admin-actions')}
            className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1"
          >
            View Complete Audit Log <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {recentActions.map(action => (
            <div key={action.id} className="py-2.5 flex items-center justify-between gap-3">
              <div>
                <span className="font-bold text-slate-900">{action.adminName}</span>
                <span className="text-slate-400 ml-1">({action.adminTitle || 'Admin'})</span>
                <span className="mx-2 text-slate-300">•</span>
                <span className="font-mono text-purple-700 font-semibold">{action.action}</span>
                <span className="text-slate-600 ml-2">{action.details}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                {new Date(action.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
