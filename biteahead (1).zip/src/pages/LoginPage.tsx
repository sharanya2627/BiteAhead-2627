import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  UtensilsCrossed,
  ShieldCheck,
  ArrowRight,
  AlertCircle,
  KeyRound,
  Mail,
  User as UserIcon,
  LogIn,
  UserPlus,
  Building2,
  CheckCircle2,
} from 'lucide-react';

interface LoginPageProps {
  onSuccess: () => void;
  initialMode?: 'signin' | 'signup';
  initialRole?: 'student' | 'admin';
}

type AuthMode = 'signin' | 'signup';
type UserRole = 'student' | 'admin';

export const LoginPage: React.FC<LoginPageProps> = ({
  onSuccess,
  initialMode = 'signin',
  initialRole = 'student',
}) => {
  const { loginWithEmail, registerWithEmail, loginWithGoogle } = useAuth();

  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [role, setRole] = useState<UserRole>(initialRole);

  React.useEffect(() => {
    if (initialMode) setMode(initialMode);
  }, [initialMode]);

  React.useEffect(() => {
    if (initialRole) setRole(initialRole);
  }, [initialRole]);

  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [adminTitle, setAdminTitle] = useState('Canteen Staff');

  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState<boolean>(false);
  const [configNotFound, setConfigNotFound] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const formatAuthError = (err: any): string => {
    const code = err?.code || '';
    if (code === 'auth/configuration-not-found' || err?.message?.includes('auth/configuration-not-found')) {
      return `Google Sign-In is not enabled in your Firebase Console for project "${firebaseConfig.projectId}". Enable Google under Authentication > Sign-in method, or sign in using Email & Password below.`;
    }
    if (code === 'auth/operation-not-allowed' || err?.message?.includes('auth/operation-not-allowed')) {
      return `This sign-in provider is disabled in your Firebase Console for "${firebaseConfig.projectId}". Enable it in Firebase Console (Authentication > Sign-in method).`;
    }
    if (code === 'auth/unauthorized-domain' || err?.message?.includes('auth/unauthorized-domain')) {
      const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'this domain';
      return `Google Sign-In is blocked: "${currentHost}" is not yet added to Authorized Domains in your Firebase Console for ${firebaseConfig.projectId}. You can sign in using Email & Password below, or add this domain in Firebase Console (Authentication > Settings > Authorized domains).`;
    }
    if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
      return 'Invalid email or password. Please check your credentials or create a new account.';
    }
    if (code === 'auth/email-already-in-use') {
      return 'An account with this email already exists. Please sign in instead.';
    }
    if (code === 'auth/weak-password') {
      return 'Password is too short. Please use at least 6 characters.';
    }
    if (code === 'auth/popup-closed-by-user') {
      return 'Google Sign-In popup was closed before completing.';
    }
    if (code === 'auth/popup-blocked') {
      return 'Popup was blocked by your browser. Please allow popups for this site to sign in with Google.';
    }
    if (code === 'auth/network-request-failed') {
      return 'Network connection issue. Please check your connection and try again.';
    }
    return err?.message || 'Authentication failed. Please try again.';
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setUnauthorizedDomain(false);
    setConfigNotFound(false);
    setGoogleLoading(true);
    try {
      await loginWithGoogle(
        role,
        role === 'admin' ? adminTitle : undefined,
        email.trim() || 'sharanyasoma505@gmail.com',
        name.trim() || (email.includes('sharanya') ? 'Sharanya Soma' : undefined)
      );
      onSuccess();
    } catch (err: any) {
      if (err?.code === 'auth/unauthorized-domain' || err?.message?.includes('auth/unauthorized-domain')) {
        setUnauthorizedDomain(true);
      }
      if (err?.code === 'auth/configuration-not-found' || err?.message?.includes('auth/configuration-not-found')) {
        setConfigNotFound(true);
      }
      setError(formatAuthError(err));
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'signin') {
        const user = await loginWithEmail(email, password, role, role === 'admin' ? adminTitle : undefined);
        if (role === 'admin' && user.role !== 'admin') {
          throw new Error('This account does not have staff/admin privileges. Please sign in via the Student Portal.');
        }
        onSuccess();
      } else {
        await registerWithEmail(
          email,
          password,
          name,
          role === 'student' ? studentId : undefined,
          role,
          role === 'admin' ? adminTitle : undefined
        );
        onSuccess();
      }
    } catch (err: any) {
      setError(formatAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-10 space-y-6">
      {/* Brand Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/25 mb-1">
          <UtensilsCrossed className="w-7 h-7" />
        </div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Bite<span className="text-amber-500">Ahead</span>
        </h1>
        <p className="text-slate-500 text-xs sm:text-sm">
          Campus Canteen Pre-order System
        </p>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        {/* Role Category Tabs */}
        <div className="flex rounded-2xl bg-slate-100 p-1 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setRole('student');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              role === 'student'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            🎓 Student Portal
          </button>
          <button
            type="button"
            onClick={() => {
              setRole('admin');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              role === 'admin'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
            👨‍🍳 Canteen Staff
          </button>
        </div>

        {/* Google Sign In Button */}
        <div>
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={googleLoading || loading}
            className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-50 disabled:opacity-50 text-slate-700 font-semibold text-xs transition-all flex items-center justify-center gap-3 shadow-xs cursor-pointer"
          >
            {/* Google "G" 4-color SVG */}
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>
              {googleLoading ? 'Connecting to Google...' : `Continue with Google (${role === 'admin' ? 'Staff' : 'Student'})`}
            </span>
          </button>

          {configNotFound && (
            <div className="mt-3 p-3.5 rounded-2xl bg-amber-50 border border-amber-300 text-xs text-amber-950 space-y-2 text-left">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-900">Google Sign-In Provider Not Enabled:</span>
                  <p className="text-[11px] text-amber-800 mt-1 leading-relaxed">
                    In your Firebase Console for <code className="font-mono bg-amber-100 px-1 py-0.5 rounded text-amber-900">{firebaseConfig.projectId}</code>, 
                    Google is not enabled under Authentication yet:
                  </p>
                  <ol className="text-[11px] text-amber-900 list-decimal list-inside mt-1.5 space-y-0.5">
                    <li>Open <strong>Firebase Console &gt; Authentication &gt; Sign-in method</strong></li>
                    <li>Click <strong>Add new provider</strong> &gt; <strong>Google</strong></li>
                    <li>Toggle <strong>Enable</strong>, select support email, and Save</li>
                  </ol>
                </div>
              </div>
              <div className="pt-1 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (!email) setEmail('sharanyasoma505@gmail.com');
                    setError(null);
                    setConfigNotFound(false);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-[11px] shadow-sm transition-all cursor-pointer"
                >
                  Sign In with Email &amp; Password Below ↓
                </button>
              </div>
            </div>
          )}

          {unauthorizedDomain && (
            <div className="mt-3 p-3.5 rounded-2xl bg-amber-50 border border-amber-300 text-xs text-amber-950 space-y-2 text-left">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-900">Google Sign-In Domain Not Authorized:</span>
                  <p className="text-[11px] text-amber-800 mt-0.5">
                    Firebase project <code>{firebaseConfig.projectId}</code> requires adding this preview domain to <strong>Authentication &gt; Settings &gt; Authorized domains</strong>.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(window.location.hostname);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-amber-200/80 hover:bg-amber-300 text-amber-950 font-mono text-[10px] font-bold transition-colors cursor-pointer"
                >
                  {copied ? '✓ Copied to clipboard!' : `Copy "${typeof window !== 'undefined' ? window.location.hostname : 'preview-domain'}"`}
                </button>
                <span className="text-[10px] text-amber-700 font-medium">or use Email below</span>
              </div>
            </div>
          )}
        </div>

        {/* Quick Demo Fill Buttons */}
        <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
          <span className="text-[11px] text-slate-500 font-semibold">Quick Demo Login:</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                setRole('student');
                setMode('signin');
                setEmail('student@college.edu');
                setPassword('student123');
                setError(null);
                setUnauthorizedDomain(false);
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-[11px] transition-colors cursor-pointer"
            >
              Student Demo
            </button>
            <button
              type="button"
              onClick={() => {
                setRole('admin');
                setMode('signin');
                setEmail('admin@canteen.edu');
                setPassword('admin123');
                setError(null);
                setUnauthorizedDomain(false);
              }}
              className="px-2.5 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-[11px] transition-colors cursor-pointer"
            >
              Staff Demo
            </button>
          </div>
        </div>

        {/* Divider */}
        <div className="relative flex items-center justify-center">
          <div className="border-t border-slate-200 w-full" />
          <span className="bg-white px-3 text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
            Or with email
          </span>
        </div>

        {/* Sign In vs Sign Up Tabs */}
        <div className="flex border-b border-slate-100 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setMode('signin');
              setError(null);
            }}
            className={`flex-1 pb-2.5 text-center font-bold border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              mode === 'signin'
                ? role === 'admin'
                  ? 'border-purple-600 text-purple-700'
                  : 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setError(null);
            }}
            className={`flex-1 pb-2.5 text-center font-bold border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              mode === 'signup'
                ? role === 'admin'
                  ? 'border-purple-600 text-purple-700'
                  : 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            Create Account
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    required
                  />
                </div>
              </div>

              {role === 'student' ? (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Student ID / Roll Number <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={studentId}
                    onChange={e => setStudentId(e.target.value)}
                    placeholder="e.g. 25MVCS001"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 uppercase focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Staff / Department Role</label>
                  <div className="relative">
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={adminTitle}
                      onChange={e => setAdminTitle(e.target.value)}
                      placeholder="e.g. Kitchen Supervisor"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      required
                    />
                  </div>
                </div>
              )}
            </>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={role === 'admin' ? 'staff@canteen.edu' : 'student@college.edu'}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                minLength={6}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || googleLoading}
            className={`w-full py-3 rounded-xl disabled:opacity-50 text-white font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
              role === 'admin'
                ? 'bg-purple-700 hover:bg-purple-800 shadow-purple-700/20'
                : 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20'
            }`}
          >
            {loading ? (
              <span>Authenticating with Firebase...</span>
            ) : mode === 'signin' ? (
              <>
                <span>Sign In to {role === 'admin' ? 'Staff Portal' : 'Student Portal'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>Create {role === 'admin' ? 'Staff' : 'Student'} Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Security and Real Firebase Notice */}
        <div className="pt-2 text-center text-[11px] text-slate-500 flex flex-col items-center justify-center gap-1 py-2 px-3 bg-slate-50 rounded-xl border border-slate-100">
          <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>Connected to Firebase: <strong className="font-mono text-amber-700">{firebaseConfig.projectId}</strong></span>
          </div>
          <span className="text-[10px] text-slate-400">Student & Admin profiles, credentials, and pre-orders saved to Cloud Firestore</span>
        </div>
      </div>
    </div>
  );
};
