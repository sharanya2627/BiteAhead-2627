import React, { useState, useEffect } from 'react';
import { FoodItem, Order } from '../types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useCart } from '../context/CartContext.tsx';
import { apiFetch } from '../lib/api.ts';
import { FoodCard } from '../components/FoodCard.tsx';
import { OrderStatusBar } from '../components/OrderStatusBar.tsx';
import { MOCK_FOOD_ITEMS } from '../data/mockMenu.ts';
import { Sparkles, UtensilsCrossed, ArrowRight, Flame } from 'lucide-react';

interface StudentDashboardProps {
  onNavigate: (tab: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { totalItemCount } = useCart();

  const defaultFeatured = [
    MOCK_FOOD_ITEMS.find(f => f.category === 'Fast Food'),
    MOCK_FOOD_ITEMS.find(f => f.category === 'Brown Bear'),
    MOCK_FOOD_ITEMS.find(f => f.category === 'Meals'),
    MOCK_FOOD_ITEMS.find(f => f.category === 'Waffles'),
  ].filter(Boolean) as FoodItem[];

  const [activeOrders, setActiveOrders] = useState<Order[]>([]);
  const [featuredFoods, setFeaturedFoods] = useState<FoodItem[]>(defaultFeatured);
  const [loading, setLoading] = useState(false);

  const loadData = async () => {
    try {
      if (user) {
        const orderRes = await apiFetch<{ orders: Order[] }>('/api/student/orders').catch(() => ({ orders: [] }));
        const active = (orderRes.orders || []).filter(
          o => o.status === 'Placed' || o.status === 'Accepted' || o.status === 'Preparing' || o.status === 'Ready for Pickup'
        );
        setActiveOrders(active);
      } else {
        setActiveOrders([]);
      }

      let items: FoodItem[] = MOCK_FOOD_ITEMS;
      try {
        const foodRes = await apiFetch<{ items?: FoodItem[]; foods?: FoodItem[] }>('/api/foods?availableOnly=true');
        if (foodRes.items && foodRes.items.length > 0) {
          items = foodRes.items;
        } else if (foodRes.foods && foodRes.foods.length > 0) {
          items = foodRes.foods;
        }
      } catch {
        items = MOCK_FOOD_ITEMS;
      }

      const featured = [
        items.find((f: FoodItem) => f.category === 'Fast Food'),
        items.find((f: FoodItem) => f.category === 'Brown Bear'),
        items.find((f: FoodItem) => f.category === 'Meals'),
        items.find((f: FoodItem) => f.category === 'Waffles'),
      ].filter(Boolean) as FoodItem[];

      setFeaturedFoods(featured.length > 0 ? featured : items.slice(0, 4));
    } catch (err) {
      console.warn('Dashboard using production mock menu fallback:', err);
      setFeaturedFoods(defaultFeatured);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, [user]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 text-white p-6 sm:p-10 shadow-xl border border-amber-900/30">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-semibold backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Campus Queue Elimination System</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Order Before. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">
              Pick Up On Time.
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl">
            Don't spend your 15-minute college break standing in a crowded canteen queue. Pre-order your favorite food from Fast Food, Brown Bear, Meals, or Waffles before your break starts — collected hot and ready!
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('menu')}
              className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-sm transition-all shadow-lg shadow-amber-500/25 flex items-center gap-2 hover:scale-[1.02] cursor-pointer"
            >
              <UtensilsCrossed className="w-4 h-4 text-slate-950" />
              Browse Canteen Menu
              <ArrowRight className="w-4 h-4" />
            </button>

            {totalItemCount > 0 && (
              <button
                onClick={() => onNavigate('cart')}
                className="px-5 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-amber-300 border border-slate-700 font-bold text-sm transition-all flex items-center gap-2 cursor-pointer"
              >
                Go to Cart ({totalItemCount} items)
              </button>
            )}
          </div>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-20 pointer-events-none hidden lg:flex items-center justify-center">
          <UtensilsCrossed className="w-80 h-80 text-amber-400 rotate-12" />
        </div>
      </div>

      {/* Break Time Schedule Info */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
            10:30
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Morning Break</div>
            <div className="text-[11px] text-slate-500">Puffs, Sandwiches & Chai</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center font-bold">
            12:30
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Lunch Break</div>
            <div className="text-[11px] text-slate-500">Fried Rice, Meals & Manchurian</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
            03:30
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Afternoon Break</div>
            <div className="text-[11px] text-slate-500">Waffles, Mojitos & Fries</div>
          </div>
        </div>
      </div>

      {/* Live Active Orders */}
      {activeOrders.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></span>
              <h2 className="text-xl font-extrabold text-slate-900">
                Your Active Pre-Orders ({activeOrders.length})
              </h2>
            </div>
            <button
              onClick={() => onNavigate('orders')}
              className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
            >
              View Order History <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-6">
            {activeOrders.map(order => (
              <div
                key={order.id}
                className="bg-white rounded-3xl p-6 border-2 border-amber-200 shadow-md space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-extrabold text-base text-slate-900">
                        {order.orderId}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                        {order.status}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Pickup Target: <strong className="text-slate-800">{order.pickupSlot}</strong>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-extrabold font-mono text-slate-900">
                      Total: ₹{order.totalAmount}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Est. Prep Time: {order.estimatedPrepTime || 10} mins
                    </div>
                  </div>
                </div>

                <OrderStatusBar
                  status={order.status}
                  orderId={order.orderId}
                  pickupSlot={order.pickupSlot}
                  handlingAdminName={order.handlingAdminName}
                  handlingAdminTitle={order.handlingAdminTitle}
                />

                <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100">
                  <div className="text-xs font-bold text-slate-700 mb-2">Items in Preparation:</div>
                  <div className="flex flex-wrap gap-2">
                    {order.items?.map((item, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white border border-slate-200 text-xs font-medium text-slate-800"
                      >
                        <span className="font-bold text-amber-600 font-mono">{item.quantity}x</span>
                        {item.name}
                        <span className="text-slate-400 text-[10px] font-mono">₹{item.priceAtOrderTime}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Popular in Campus */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-500" />
              Popular in Campus Today
            </h2>
            <p className="text-xs text-slate-500">
              Canteen manager and chef verified available items ready to pre-order
            </p>
          </div>
          <button
            onClick={() => onNavigate('menu')}
            className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
          >
            See Full Menu <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredFoods.map(food => (
            <FoodCard key={food.id} food={food} />
          ))}
        </div>
      </div>

      {/* Value Proposition */}
      <div className="bg-amber-500/10 border border-amber-500/20 rounded-3xl p-6 sm:p-8">
        <h3 className="text-lg font-extrabold text-amber-950 mb-3 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-600" />
          The BiteAhead Hackathon Value Proposition
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-amber-900">
          <div className="p-4 bg-white/80 rounded-2xl border border-amber-200/50">
            <div className="font-bold text-sm text-slate-900 mb-1">⏱ Save 15-20 Min Queues</div>
            Students order before class ends. The canteen kitchen prepares the items ahead of the rush.
          </div>
          <div className="p-4 bg-white/80 rounded-2xl border border-amber-200/50">
            <div className="font-bold text-sm text-slate-900 mb-1">🔒 Server-Side Price Security</div>
            Backend calculates prices directly from the SQL database to prevent client-side cart tampering.
          </div>
          <div className="p-4 bg-white/80 rounded-2xl border border-amber-200/50">
            <div className="font-bold text-sm text-slate-900 mb-1">👨‍🍳 4 Admin Kitchen Role System</div>
            Fast Food, Meals, Brown Bear, and Manager can toggle availability and progress order stages in real time.
          </div>
        </div>
      </div>
    </div>
  );
};
