import React, { useState, useEffect, useMemo } from 'react';
import { FoodItem, FoodCategory } from '../types.ts';
import { useCart } from '../context/CartContext.tsx';
import { apiFetch } from '../lib/api.ts';
import { CategoryPills } from '../components/CategoryPills.tsx';
import { FoodCard } from '../components/FoodCard.tsx';
import { MOCK_FOOD_ITEMS } from '../data/mockMenu.ts';
import { Search, RefreshCw, AlertCircle, ShoppingBag, ArrowRight } from 'lucide-react';

interface MenuPageProps {
  onNavigate: (tab: string) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({ onNavigate }) => {
  const [foods, setFoods] = useState<FoodItem[]>(MOCK_FOOD_ITEMS);
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<FoodCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [availableOnly, setAvailableOnly] = useState(false);

  const { totalItemCount, subtotal } = useCart();

  const loadFoods = async () => {
    try {
      setLoading(true);
      const res = await apiFetch<{ items?: FoodItem[]; foods?: FoodItem[] }>('/api/foods');
      const items = res.items && res.items.length > 0 ? res.items : (res.foods && res.foods.length > 0 ? res.foods : MOCK_FOOD_ITEMS);
      setFoods(items);
    } catch (err) {
      console.warn('Backend foods API unavailable, showing production mock menu:', err);
      setFoods(MOCK_FOOD_ITEMS);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFoods();
  }, []);

  const counts = useMemo(() => {
    const record: Record<string, number> = {};
    for (const item of foods) {
      record[item.category] = (record[item.category] || 0) + 1;
    }
    return record;
  }, [foods]);

  const filteredFoods = useMemo(() => {
    return foods.filter(item => {
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchAvail = !availableOnly || item.isAvailable === 1;
      return matchCat && matchSearch && matchAvail;
    });
  }, [foods, selectedCategory, searchQuery, availableOnly]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold uppercase tracking-wider mb-2">
            Campus Canteen Pre-Order Menu
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Order Your Break Meal</h1>
          <p className="text-slate-500 text-sm mt-1">
            Choose from authentic Fast Food, Brown Bear Bakery, Indian Mess Meals, Coolers, and Waffles.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[260px] sm:min-w-[300px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search noodles, sandwich, meals, mojito..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:border-amber-500 shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          <button
            onClick={() => setAvailableOnly(!availableOnly)}
            className={`px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-2 cursor-pointer ${
              availableOnly
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${availableOnly ? 'bg-emerald-500' : 'bg-slate-300'}`} />
            Available Only
          </button>

          <button
            onClick={loadFoods}
            className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            title="Refresh menu availability"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Category Pills */}
      <div className="sticky top-16 z-30 bg-slate-50/95 backdrop-blur-md pt-2 pb-3">
        <CategoryPills selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} counts={counts} />
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 py-12">
          {[...Array(8)].map((_, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3 animate-pulse">
              <div className="aspect-16/10 bg-slate-200 rounded-xl" />
              <div className="h-4 bg-slate-200 rounded-md w-3/4" />
              <div className="h-3 bg-slate-100 rounded-md w-1/2" />
              <div className="h-8 bg-slate-200 rounded-xl mt-4" />
            </div>
          ))}
        </div>
      ) : filteredFoods.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="font-bold text-slate-800 text-base">No food items found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search query or selecting a different canteen category above.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setAvailableOnly(false);
            }}
            className="px-4 py-2 rounded-xl bg-amber-500 text-white font-bold text-xs cursor-pointer"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredFoods.map(food => (
            <FoodCard key={food.id} food={food} />
          ))}
        </div>
      )}

      {/* Floating Bottom Cart Bar */}
      {totalItemCount > 0 && (
        <div className="fixed bottom-6 left-4 right-4 z-40 max-w-2xl mx-auto">
          <div className="bg-slate-900 text-white rounded-2xl p-3.5 sm:p-4 shadow-2xl border border-slate-700 flex items-center justify-between gap-4 animate-in fade-in slide-in-from-bottom-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-medium text-slate-400">
                  {totalItemCount} {totalItemCount === 1 ? 'item' : 'items'} in Break Cart
                </div>
                <div className="text-base font-extrabold font-mono text-white">Total: ₹{subtotal}</div>
              </div>
            </div>

            <button
              onClick={() => onNavigate('cart')}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition-all flex items-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer"
            >
              Select Break Slot & Checkout
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
