import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { apiFetch } from '../lib/api.ts';
import { LogOut } from 'lucide-react';

interface StudentProfilePageProps {
  onNavigate: (tab: string) => void;
}

interface StudentStats {
  totalOrders: number;
  totalSpent: number;
}

export const StudentProfilePage: React.FC<StudentProfilePageProps> = ({ onNavigate }) => {
  const { user, firebaseUser, logout } = useAuth();
  const [stats, setStats] = useState<StudentStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    apiFetch<{ stats: StudentStats }>('/api/student/profile')
      .then(res => {
        setStats(res.stats);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const totalOrders = stats?.totalOrders || 0;
  const timeSaved = totalOrders * 15;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4">
            {firebaseUser?.photoURL ? (
              <img
                src={firebaseUser.photoURL}
                alt={user?.name || 'Profile'}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-200 shadow-md shadow-amber-500/10"
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white font-extrabold text-2xl flex items-center justify-center shadow-lg shadow-amber-500/20">
                {(user?.name || 'S').charAt(0).toUpperCase()}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-extrabold text-slate-900">{user?.name}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 uppercase">
                  {user?.role}
                </span>
              </div>
              <div className="text-xs text-slate-500 mt-1 flex items-center gap-3">
                <span>
                  Student ID: <strong className="font-mono text-slate-700">{user?.studentId}</strong>
                </span>
                <span>•</span>
                <span>{user?.email}</span>
              </div>
            </div>
          </div>

          <button
            onClick={logout}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 font-bold text-xs transition-colors flex items-center gap-2 self-start sm:self-auto cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200">
            <div className="text-xs font-bold text-amber-800">Total Pre-Orders Placed</div>
            <div className="text-2xl font-extrabold font-mono text-amber-950 mt-1">{totalOrders}</div>
            <div className="text-[11px] text-amber-600 mt-0.5">Successful campus pickups</div>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200">
            <div className="text-xs font-bold text-emerald-800">Queue Time Saved</div>
            <div className="text-2xl font-extrabold font-mono text-emerald-950 mt-1">~{timeSaved} mins</div>
            <div className="text-[11px] text-emerald-600 mt-0.5">Relaxed break duration</div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="text-xs font-bold text-slate-700">Total Canteen Spending</div>
            <div className="text-2xl font-extrabold font-mono text-slate-900 mt-1">₹{stats?.totalSpent || 0}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Pre-ordered meals</div>
          </div>
        </div>

        <div className="pt-4 flex flex-wrap gap-3">
          <button
            onClick={() => onNavigate('menu')}
            className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 cursor-pointer"
          >
            Browse Canteen Menu
          </button>
          <button
            onClick={() => onNavigate('orders')}
            className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs cursor-pointer"
          >
            Track Active Orders
          </button>
        </div>
      </div>
    </div>
  );
};
