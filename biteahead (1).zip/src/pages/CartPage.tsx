import React, { useState } from 'react';
import { useCart } from '../context/CartContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { auth } from '../lib/firebase.ts';
import {
  ShoppingCart,
  Trash2,
  Plus,
  Minus,
  Clock,
  Calendar,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  UtensilsCrossed,
  Info,
  CheckCircle2,
  LogIn,
} from 'lucide-react';

interface CartPageProps {
  onNavigate: (tab: string) => void;
  onOrderPlaced: (orderId: string) => void;
}

export const CartPage: React.FC<CartPageProps> = ({ onNavigate, onOrderPlaced }) => {
  const { user, firebaseUser, refreshUser } = useAuth();
  const isAuthenticated = Boolean(user || firebaseUser || auth.currentUser);
  const {
    cart,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    totalItemCount,
    pickupSlots,
    selectedSlot,
    setSelectedSlot,
    notes,
    setNotes,
    placeOrder,
    isSubmitting,
    error,
    setError,
  } = useCart();

  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);

  // Student contact info for order placement and Firestore sync
  const [studentName, setStudentName] = useState<string>(() => user?.name || firebaseUser?.displayName || '');
  const [studentEmail, setStudentEmail] = useState<string>(() => user?.email || firebaseUser?.email || '');
  const [studentRollNo, setStudentRollNo] = useState<string>(() => user?.studentId || '');
  const [validationMsg, setValidationMsg] = useState<string | null>(null);

  // Sync when user logs in
  React.useEffect(() => {
    if (user) {
      if (!studentName) setStudentName(user.name);
      if (!studentEmail) setStudentEmail(user.email);
      if (!studentRollNo) setStudentRollNo(user.studentId);
    } else if (firebaseUser) {
      if (!studentName && firebaseUser.displayName) setStudentName(firebaseUser.displayName);
      if (!studentEmail && firebaseUser.email) setStudentEmail(firebaseUser.email);
    }
  }, [user, firebaseUser]);

  // Maximum prep time among selected items
  const maxPrepMinutes = cart.length > 0
    ? Math.max(...cart.map(c => c.food.preparationTime))
    : 0;

  const handleCheckout = async () => {
    setError(null);
    setValidationMsg(null);

    // If not authenticated and no email provided, guide the user
    if (!isAuthenticated) {
      if (!studentEmail.trim()) {
        setValidationMsg('Please enter your Student Email address so we can save your order & profile to Firebase Firestore.');
        return;
      }
      if (!studentName.trim()) {
        setValidationMsg('Please enter your Name for kitchen order pickup.');
        return;
      }
    }

    try {
      if (!user && (firebaseUser || auth.currentUser)) {
        await refreshUser().catch(() => {});
      }

      const order = await placeOrder(
        !isAuthenticated
          ? {
              name: studentName.trim(),
              email: studentEmail.trim().toLowerCase(),
              studentId: studentRollNo.trim().toUpperCase() || undefined,
            }
          : undefined
      );

      setOrderSuccess(order.orderId);
      setTimeout(() => {
        onOrderPlaced(order.orderId);
      }, 1500);
    } catch (err: any) {
      console.error('Order placement error:', err);
    }
  };

  if (orderSuccess) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center animate-bounce">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-extrabold text-slate-900">Pre-Order Successfully Placed!</h2>
        <p className="text-sm text-slate-600">
          Order ID: <strong className="font-mono text-amber-600 text-base">{orderSuccess}</strong>
        </p>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          The canteen kitchen has received your order and will prepare it for your selected break slot. Redirecting to your orders tracker...
        </p>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
          <ShoppingCart className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">Your Break Cart is Empty</h2>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          Pre-order your meal before your college break starts so the kitchen can prepare it in advance.
        </p>
        <button
          onClick={() => onNavigate('menu')}
          className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs transition-all shadow-md shadow-amber-500/20"
        >
          Browse Canteen Menu
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-amber-500" />
            Review Break Pre-Order
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Pick your break slot so food is prepared and waiting for you
          </p>
        </div>
        <button
          onClick={clearCart}
          className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 p-2"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear Cart
        </button>
      </div>

      {/* Backend Error Alert (Availability / Slot validation) */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold">Backend Validation Notice: </span>
            {error}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Cart Items List */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-xs">
            {cart.map(item => (
              <div key={item.food.id} className="p-4 sm:p-5 flex items-center gap-4">
                <img
                  src={item.food.image}
                  alt={item.food.name}
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover shrink-0 border border-slate-100"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm truncate">{item.food.name}</h4>
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                        {item.food.category}
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-extrabold text-slate-900 text-sm">
                        ₹{item.food.price * item.quantity}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        ₹{item.food.price} each
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    {/* Quantity controls */}
                    <div className="flex items-center gap-2 bg-slate-100 rounded-lg p-1 border border-slate-200">
                      <button
                        onClick={() => updateQuantity(item.food.id, -1)}
                        className="w-6 h-6 rounded-md bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-mono font-bold text-xs text-slate-800 px-2">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.food.id, 1)}
                        className="w-6 h-6 rounded-md bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center font-bold text-xs transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="flex items-center gap-4">
                      <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3" /> {item.food.preparationTime}m prep
                      </span>
                      <button
                        onClick={() => removeFromCart(item.food.id)}
                        className="text-slate-400 hover:text-rose-600 transition-colors"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Kitchen Preparation Special Notes */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 space-y-2 shadow-xs">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <UtensilsCrossed className="w-3.5 h-3.5 text-amber-500" />
              Special Kitchen Instructions (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Less spicy Manchurian, extra mint chutney with sandwich..."
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              maxLength={150}
            />
          </div>
        </div>

        {/* Right: Break Slot Selection & Order Summary */}
        <div className="lg:col-span-5 space-y-6">
          {/* Pickup Slot Selection (Section 9 Requirement) */}
          <div className="bg-white rounded-3xl p-5 border-2 border-amber-300 shadow-xs space-y-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wide">
                  Select Break Pickup Slot (Required)
                </h3>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                The kitchen prioritizes batch cooking to match your break start time.
              </p>
            </div>

            <div className="space-y-2">
              {pickupSlots.map(slot => {
                const formatted = `${slot.slotTime} — ${slot.label}`;
                const isSelected = selectedSlot === formatted || selectedSlot === slot.slotTime;

                return (
                  <label
                    key={slot.id}
                    className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-400/20 text-amber-950 font-bold'
                        : 'bg-slate-50/50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="pickupSlot"
                        checked={isSelected}
                        onChange={() => setSelectedSlot(formatted)}
                        className="text-amber-500 focus:ring-amber-400 h-4 w-4"
                      />
                      <div>
                        <span className="font-mono text-xs">{slot.slotTime}</span>
                        <div className="text-[11px] text-slate-500">{slot.label}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      Canteen Ready
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Backend Total Verification Box */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm">Order Summary</h3>

            <div className="space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Items Subtotal ({totalItemCount} items)</span>
                <span className="font-mono font-semibold text-slate-900">₹{subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Canteen Convenience Fee</span>
                <span className="font-mono text-emerald-600 font-bold">₹0 (Free)</span>
              </div>
              <div className="flex justify-between">
                <span>Max Kitchen Prep Time</span>
                <span className="font-mono text-slate-700 font-semibold">{maxPrepMinutes} mins</span>
              </div>

              <div className="pt-2 border-t border-slate-100 flex justify-between items-baseline">
                <span className="text-sm font-extrabold text-slate-900">Final Total</span>
                <span className="text-xl font-extrabold font-mono text-amber-600">₹{subtotal}</span>
              </div>
            </div>

            <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-[11px] text-amber-900 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                <strong>Backend Security:</strong> Prices and availability will be verified directly from the canteen database upon submission.
              </span>
            </div>

            {validationMsg && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs font-semibold flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>{validationMsg}</span>
              </div>
            )}

            {/* Student Account or Instant Pre-order Details */}
            {isAuthenticated ? (
              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Student Pre-Order Profile
                  </span>
                  <button
                    type="button"
                    onClick={() => onNavigate('profile')}
                    className="text-[11px] text-emerald-700 underline font-semibold hover:text-emerald-800"
                  >
                    View Profile
                  </button>
                </div>
                <div className="font-extrabold text-slate-900">{user?.name || firebaseUser?.displayName || 'Student'}</div>
                <div className="text-[11px] text-slate-600 font-mono">
                  {user?.email || firebaseUser?.email || ''} • {user?.studentId || 'Canteen Student'}
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    🎓 Student Pre-Order Details
                  </span>
                  <button
                    type="button"
                    onClick={() => onNavigate('login')}
                    className="text-[11px] text-amber-700 font-bold hover:underline"
                  >
                    Or Sign In →
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Enter your student details below so the kitchen can identify your order and save to Firebase Firestore.
                </p>

                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Your Full Name *</label>
                    <input
                      type="text"
                      value={studentName}
                      onChange={e => setStudentName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Student Email Address *</label>
                    <input
                      type="email"
                      value={studentEmail}
                      onChange={e => setStudentEmail(e.target.value)}
                      placeholder="e.g. student@college.edu or gmail"
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Roll Number / Student ID (Optional)</label>
                    <input
                      type="text"
                      value={studentRollNo}
                      onChange={e => setStudentRollNo(e.target.value)}
                      placeholder="e.g. 25MVCS001"
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 uppercase focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Place Order Button - ALWAYS ACTIVE & CLICKABLE */}
            <button
              type="button"
              onClick={handleCheckout}
              disabled={isSubmitting}
              className="w-full py-4 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              {isSubmitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                  Saving Pre-Order &amp; Student Data to Firestore...
                </>
              ) : (
                <>
                  Place Order &amp; Confirm Break Pickup
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {!isAuthenticated && (
              <div className="flex items-center justify-between pt-1 text-xs text-slate-500">
                <span>Already have a canteen account?</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onNavigate('login')}
                    className="font-bold text-slate-800 hover:text-amber-600 cursor-pointer"
                  >
                    Sign In
                  </button>
                  <span>•</span>
                  <button
                    type="button"
                    onClick={() => onNavigate('signup')}
                    className="font-bold text-amber-600 hover:underline cursor-pointer"
                  >
                    Sign Up
                  </button>
                </div>
              </div>
            )}

            <div className="pt-2 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Real-time pre-order stored in Firebase Firestore (<code className="font-mono">biteahead-2627</code>)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
