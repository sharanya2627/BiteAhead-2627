import React, { useState, useEffect } from 'react';
import { Order, OrderStatus } from '../types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { apiFetch } from '../lib/api.ts';
import { updateOrderStatusInFirestore, getAllOrdersFromFirestore } from '../lib/firebase.ts';
import { Layers, Search, RefreshCw, Eye } from 'lucide-react';

export const AdminOrdersPage: React.FC = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      // Try backend Express first if available
      try {
        const res = await apiFetch<{ orders: Order[] }>('/api/admin/orders');
        if (res.orders && res.orders.length > 0) {
          setOrders(res.orders);
          return;
        }
      } catch {}

      // Direct Firebase Firestore fetch
      const fbOrders = await getAllOrdersFromFirestore();
      if (fbOrders && fbOrders.length > 0) {
        setOrders(fbOrders as Order[]);
      } else if (orders.length === 0) {
        setOrders([]);
      }
    } catch (err) {
      console.error('Failed to load admin orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 8000);
    return () => clearInterval(interval);
  }, []);

  const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
    try {
      // 1. Update directly in Firebase Firestore first
      await updateOrderStatusInFirestore(orderId, status, user?.name, user?.adminTitle);

      // 2. Optimistically update local state
      setOrders(prev => prev.map(o => o.orderId === orderId ? { ...o, status } : o));
      if (selectedOrder && selectedOrder.orderId === orderId) {
        setSelectedOrder(prev => (prev ? { ...prev, status } : null));
      }

      // 3. Sync with backend SQLite if running
      try {
        await apiFetch(`/api/orders/${orderId}/status`, {
          method: 'PUT',
          body: JSON.stringify({ status }),
        });
      } catch {}
    } catch (err: any) {
      console.error('Error updating order:', err);
    }
  };

  const filteredOrders = orders.filter(o => {
    const matchStatus = statusFilter === 'All' || o.status === statusFilter;
    const matchSearch =
      o.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.studentName && o.studentName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (o.collegeStudentId && o.collegeStudentId.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchStatus && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-6 h-6 text-amber-500" />
            Canteen Orders Master Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time feed of all student pre-orders across campus collection break slots.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search Order ID, Student ID, or Name..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold bg-white text-slate-700"
          >
            <option value="All">All Statuses</option>
            <option value="Placed">Placed</option>
            <option value="Accepted">Accepted</option>
            <option value="Preparing">Preparing</option>
            <option value="Ready for Pickup">Ready for Pickup</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>

          <button
            onClick={fetchOrders}
            className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 cursor-pointer"
            title="Refresh orders"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Order ID</th>
                <th className="py-3.5 px-4">Student</th>
                <th className="py-3.5 px-4">Pickup Slot</th>
                <th className="py-3.5 px-4">Items Summary</th>
                <th className="py-3.5 px-4">Total</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Handler</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No matching canteen orders found.
                  </td>
                </tr>
              ) : (
                filteredOrders.map(order => (
                  <tr key={order.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {order.orderId}
                      <div className="text-[10px] text-slate-400 font-normal">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-800">{order.studentName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{order.collegeStudentId}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 text-[11px]">
                        {order.pickupSlot}
                      </span>
                    </td>
                    <td className="py-3 px-4 max-w-xs">
                      <div className="truncate text-slate-700">
                        {order.items?.map(it => `${it.quantity}x ${it.name}`).join(', ')}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono font-extrabold text-slate-900">
                      ₹{order.totalAmount}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          order.status === 'Ready for Pickup'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.status === 'Preparing'
                            ? 'bg-blue-100 text-blue-800'
                            : order.status === 'Accepted'
                            ? 'bg-amber-100 text-amber-900'
                            : order.status === 'Completed'
                            ? 'bg-slate-100 text-slate-700'
                            : order.status === 'Cancelled'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-[11px]">
                      {order.handlingAdminName ? (
                        <span className="text-slate-700 font-medium">{order.handlingAdminName}</span>
                      ) : (
                        <span className="text-slate-400 italic">Unassigned</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {order.status === 'Placed' && (
                          <button
                            onClick={() => handleUpdateStatus(order.orderId, 'Accepted')}
                            className="px-2 py-1 rounded-md bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-[10px] cursor-pointer"
                          >
                            Accept
                          </button>
                        )}
                        {order.status === 'Accepted' && (
                          <button
                            onClick={() => handleUpdateStatus(order.orderId, 'Preparing')}
                            className="px-2 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Prepare
                          </button>
                        )}
                        {order.status === 'Preparing' && (
                          <button
                            onClick={() => handleUpdateStatus(order.orderId, 'Ready for Pickup')}
                            className="px-2 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Ready
                          </button>
                        )}
                        {order.status === 'Ready for Pickup' && (
                          <button
                            onClick={() => handleUpdateStatus(order.orderId, 'Completed')}
                            className="px-2 py-1 rounded-md bg-slate-900 hover:bg-slate-800 text-white font-bold text-[10px] cursor-pointer"
                          >
                            Complete
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
                          title="View order details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Details */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="font-mono font-extrabold text-lg text-slate-900">{selectedOrder.orderId}</span>
                <div className="text-xs text-slate-500">
                  Student: {selectedOrder.studentName} ({selectedOrder.collegeStudentId})
                </div>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Break Slot:</span>
                <span className="font-bold text-slate-800">{selectedOrder.pickupSlot}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Placed At:</span>
                <span className="font-mono text-slate-700">{new Date(selectedOrder.createdAt).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Current Status:</span>
                <span className="font-bold font-mono text-amber-700">{selectedOrder.status}</span>
              </div>
              {selectedOrder.notes && (
                <div className="p-2.5 rounded-xl bg-amber-50 text-amber-900 text-xs">
                  <strong>Notes:</strong> {selectedOrder.notes}
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="text-xs font-bold text-slate-800">Items Ordered:</div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                {selectedOrder.items?.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-xs py-1 border-b border-slate-50">
                    <span>
                      <strong className="text-amber-600 font-mono">{item.quantity}x</strong> {item.name}
                    </span>
                    <span className="font-mono font-bold text-slate-800">
                      ₹{item.priceAtOrderTime * item.quantity}
                    </span>
                  </div>
                ))}
              </div>
              <div className="pt-2 flex justify-between font-extrabold text-sm text-slate-900 border-t border-slate-200">
                <span>Total Amount:</span>
                <span className="font-mono text-amber-600">₹{selectedOrder.totalAmount}</span>
              </div>
            </div>

            <div className="pt-4 flex justify-end gap-2">
              <button
                onClick={() => setSelectedOrder(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
