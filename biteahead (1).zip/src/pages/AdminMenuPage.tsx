import React, { useState, useEffect } from 'react';
import { FoodItem } from '../types.ts';
import { apiFetch } from '../lib/api.ts';
import { ChefHat, Search, Clock, SquarePen, Trash2, AlertTriangle, Plus, CheckCircle2 } from 'lucide-react';

const CATEGORIES = ['Fast Food', 'Brown Bear', 'Meals', 'Cocktail / Beverages', 'Waffles'];

export const AdminMenuPage: React.FC = () => {
  const [foods, setFoods] = useState<FoodItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<FoodItem | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'Fast Food',
    price: '',
    preparationTime: '',
    image: '',
    isAvailable: true,
  });

  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const loadMenu = async () => {
    try {
      setLoading(true);
      const res = await apiFetch<{ items?: FoodItem[]; foods?: FoodItem[] }>('/api/admin/menu');
      setFoods(res.items || res.foods || []);
    } catch (err) {
      console.error('Failed to load menu:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMenu();
  }, []);

  const openAddModal = () => {
    setEditingItem(null);
    setFormData({
      name: '',
      description: '',
      category: 'Fast Food',
      price: '',
      preparationTime: '10',
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80',
      isAvailable: true,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const openEditModal = (item: FoodItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      description: item.description,
      category: item.category,
      price: String(item.price),
      preparationTime: String(item.preparationTime),
      image: item.image,
      isAvailable: item.isAvailable === 1,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleToggleAvailability = async (item: FoodItem) => {
    try {
      const res = await apiFetch<{ isAvailable: number }>(`/api/foods/${item.id}/availability`, {
        method: 'PATCH',
      });
      setFoods(prev => prev.map(f => (f.id === item.id ? { ...f, isAvailable: res.isAvailable } : f)));
      setFeedbackMsg(`"${item.name}" is now marked ${res.isAvailable === 1 ? 'AVAILABLE' : 'UNAVAILABLE'}`);
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      alert(`Error toggling availability: ${err.message}`);
    }
  };

  const handleDelete = async (item: FoodItem) => {
    if (confirm(`Are you sure you want to remove "${item.name}" from the menu?`)) {
      try {
        await apiFetch(`/api/foods/${item.id}`, { method: 'DELETE' });
        setFeedbackMsg(`"${item.name}" removed successfully.`);
        setTimeout(() => setFeedbackMsg(null), 3000);
        await loadMenu();
      } catch (err: any) {
        alert(`Failed to remove item: ${err.message}`);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!formData.name.trim() || !formData.price || !formData.preparationTime) {
      setFormError('Please fill in Name, Price, and Preparation Time.');
      return;
    }
    const priceNum = parseFloat(formData.price);
    const prepNum = parseInt(formData.preparationTime);
    if (isNaN(priceNum) || priceNum <= 0) {
      setFormError('Price must be a valid positive number in Rupees (₹).');
      return;
    }
    if (isNaN(prepNum) || prepNum <= 0) {
      setFormError('Preparation time must be at least 1 minute.');
      return;
    }

    setSubmitting(true);
    try {
      if (editingItem) {
        await apiFetch(`/api/foods/${editingItem.id}`, {
          method: 'PUT',
          body: JSON.stringify({
            name: formData.name.trim(),
            description: formData.description.trim(),
            category: formData.category,
            price: priceNum,
            preparationTime: prepNum,
            image: formData.image.trim(),
            isAvailable: formData.isAvailable,
          }),
        });
        setFeedbackMsg(`Food item "${formData.name}" updated successfully!`);
      } else {
        await apiFetch('/api/foods', {
          method: 'POST',
          body: JSON.stringify({
            name: formData.name.trim(),
            description: formData.description.trim(),
            category: formData.category,
            price: priceNum,
            preparationTime: prepNum,
            image: formData.image.trim(),
            isAvailable: formData.isAvailable,
          }),
        });
        setFeedbackMsg(`New food item "${formData.name}" added to the canteen menu!`);
      }
      setModalOpen(false);
      setTimeout(() => setFeedbackMsg(null), 3500);
      await loadMenu();
    } catch (err: any) {
      setFormError(err.message || 'Operation failed');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredFoods = foods.filter(item => {
    const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
    const matchSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ChefHat className="w-6 h-6 text-amber-500" />
            Canteen Menu Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Admins have full authority to add items, modify prices, update prep times, and toggle live availability.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={openAddModal}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Food Item
          </button>
        </div>
      </div>

      {feedbackMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          {feedbackMsg}
        </div>
      )}

      {/* Category Pills & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 w-full sm:w-auto">
          {['All', ...CATEGORIES].map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search menu items..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Item</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Price</th>
                <th className="py-3.5 px-4">Prep Time</th>
                <th className="py-3.5 px-4">Availability</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredFoods.map(food => (
                <tr key={food.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={food.image}
                        alt={food.name}
                        className="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-100"
                        onError={e => {
                          (e.target as HTMLImageElement).src =
                            'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80';
                        }}
                      />
                      <div>
                        <div className="font-bold text-slate-900 text-sm">{food.name}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1 max-w-sm">{food.description}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-md text-[11px]">
                      {food.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono font-extrabold text-slate-900 text-sm">₹{food.price}</td>
                  <td className="py-3 px-4 font-mono text-slate-700">
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {food.preparationTime} mins
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleToggleAvailability(food)}
                      className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all border flex items-center gap-1.5 cursor-pointer ${
                        food.isAvailable === 1
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                      }`}
                      title="Click to toggle availability"
                    >
                      <span className={`w-2 h-2 rounded-full ${food.isAvailable === 1 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      {food.isAvailable === 1 ? 'Available' : 'Currently Unavailable'}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => openEditModal(food)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-amber-100 text-slate-600 hover:text-amber-800 transition-colors cursor-pointer"
                        title="Edit item"
                      >
                        <SquarePen className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(food)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 transition-colors cursor-pointer"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-slate-900 text-lg">
                {editingItem ? `Edit "${editingItem.name}"` : 'Add New Canteen Food Item'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Food Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Paneer Fried Rice"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Category *</label>
                <select
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-semibold text-slate-800"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Price (₹) *</label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    value={formData.price}
                    onChange={e => setFormData({ ...formData, price: e.target.value })}
                    placeholder="e.g. 90"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono font-bold"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Prep Time (Mins) *</label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={formData.preparationTime}
                    onChange={e => setFormData({ ...formData, preparationTime: e.target.value })}
                    placeholder="e.g. 15"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono font-bold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Short description of ingredients and spices..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Image URL</label>
                <input
                  type="url"
                  value={formData.image}
                  onChange={e => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono text-[11px]"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="availCheck"
                  checked={formData.isAvailable}
                  onChange={e => setFormData({ ...formData, isAvailable: e.target.checked })}
                  className="rounded-sm text-amber-500 focus:ring-amber-400 h-4 w-4"
                />
                <label htmlFor="availCheck" className="font-bold text-slate-800 cursor-pointer">
                  Mark as currently Available for pre-orders
                </label>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold shadow-sm cursor-pointer"
                >
                  {submitting ? 'Saving...' : editingItem ? 'Save Changes' : '+ Add Food Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
