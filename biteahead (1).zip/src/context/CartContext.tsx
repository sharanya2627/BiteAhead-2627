import React, { createContext, useContext, useState, useEffect } from 'react';
import { FoodItem, CartItem, Order, PickupSlot } from '../types.ts';
import { apiFetch } from '../lib/api.ts';
import { saveOrderToFirestore, auth } from '../lib/firebase.ts';
import { MOCK_PICKUP_SLOTS } from '../data/mockMenu.ts';

interface CartContextType {
  cart: CartItem[];
  addToCart: (food: FoodItem, quantity?: number) => void;
  updateQuantity: (foodId: number, delta: number) => void;
  removeFromCart: (foodId: number) => void;
  clearCart: () => void;
  totalItemCount: number;
  subtotal: number;
  pickupSlots: PickupSlot[];
  selectedSlot: string;
  setSelectedSlot: (slot: string) => void;
  notes: string;
  setNotes: (notes: string) => void;
  placeOrder: (guestStudent?: { name: string; email: string; studentId?: string }) => Promise<Order>;
  isSubmitting: boolean;
  error: string | null;
  setError: (err: string | null) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('biteahead_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [pickupSlots, setPickupSlots] = useState<PickupSlot[]>(MOCK_PICKUP_SLOTS);
  const [selectedSlot, setSelectedSlot] = useState<string>(
    `${MOCK_PICKUP_SLOTS[0].slotTime} — ${MOCK_PICKUP_SLOTS[0].label}`
  );
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Sync cart to local storage
  useEffect(() => {
    try {
      localStorage.setItem('biteahead_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  // Load available pickup slots from backend with mock fallback
  useEffect(() => {
    apiFetch<{ slots: PickupSlot[] }>('/api/orders/pickup-slots')
      .then(res => {
        if (res.slots && res.slots.length > 0) {
          setPickupSlots(res.slots);
          if (!selectedSlot) {
            const lunch = res.slots.find(s => s.slotTime.includes('12:30'));
            setSelectedSlot(lunch ? `${lunch.slotTime} — ${lunch.label}` : `${res.slots[0].slotTime} — ${res.slots[0].label}`);
          }
        }
      })
      .catch(() => {
        // Fallback to MOCK_PICKUP_SLOTS remains active
      });
  }, []);

  const addToCart = (food: FoodItem, quantity: number = 1) => {
    if (food.isAvailable !== 1) {
      setError(`Cannot add "${food.name}". This item is currently marked unavailable by the canteen.`);
      return;
    }

    setCart(prev => {
      const existing = prev.find(item => item.food.id === food.id);
      if (existing) {
        return prev.map(item =>
          item.food.id === food.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { food, quantity }];
    });
    setError(null);
  };

  const updateQuantity = (foodId: number, delta: number) => {
    setCart(prev =>
      prev
        .map(item => {
          if (item.food.id === foodId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const removeFromCart = (foodId: number) => {
    setCart(prev => prev.filter(item => item.food.id !== foodId));
  };

  const clearCart = () => {
    setCart([]);
    setError(null);
  };

  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.food.price * item.quantity, 0);

  const placeOrder = async (guestStudent?: { name: string; email: string; studentId?: string }): Promise<Order> => {
    if (cart.length === 0) {
      throw new Error('Your cart is empty.');
    }

    const effectiveSlot = selectedSlot || (pickupSlots.length > 0 ? `${pickupSlots[0].slotTime} — ${pickupSlots[0].label}` : '12:30 PM — Lunch Break (Shift 1)');

    setIsSubmitting(true);
    setError(null);

    try {
      const generatedOrderId = `BA-${Math.floor(10000 + Math.random() * 90000)}`;
      const maxPrep = cart.length > 0 ? Math.max(...cart.map(c => c.food.preparationTime)) : 10;
      const currentUser = auth.currentUser;

      // Determine student identifiers
      let storedUser: any = null;
      try {
        const storedStr = localStorage.getItem('biteahead_user');
        if (storedStr) storedUser = JSON.parse(storedStr);
      } catch {}

      const studentEmail = (guestStudent?.email || currentUser?.email || storedUser?.email || '').trim().toLowerCase();
      const studentName = guestStudent?.name?.trim() || currentUser?.displayName || storedUser?.name || (studentEmail ? studentEmail.split('@')[0] : 'Student');
      const studentUid = currentUser?.uid || storedUser?.uid || (studentEmail ? `stu_${studentEmail.replace(/[^a-zA-Z0-9]/g, '_')}` : `stu_${Date.now()}`);
      const studentId = guestStudent?.studentId?.trim().toUpperCase() || storedUser?.studentId || (storedUser?.role === 'admin' ? `ADMIN-${studentUid.slice(0, 4).toUpperCase()}` : `STU-${studentUid.slice(0, 6).toUpperCase()}`);

      // 1. Explicitly save/update student details in Firestore (both /users and /students)
      if (studentEmail || studentName) {
        try {
          await saveOrderToFirestore({
            orderId: generatedOrderId,
            studentUid,
            studentId,
            studentName,
            studentEmail,
            totalAmount: subtotal,
            pickupSlot: effectiveSlot,
            status: 'Placed',
            items: cart.map(item => ({
              foodItemId: item.food.id,
              name: item.food.name,
              quantity: item.quantity,
              priceAtOrderTime: item.food.price,
            })),
            notes: notes.trim(),
            estimatedPrepTime: maxPrep,
          });
        } catch (fbErr: any) {
          console.warn('🔥 [Firestore Order Save Notice]:', fbErr?.message || fbErr);
        }
      }

      // If user was a guest checkout, save their profile session to local storage for convenience
      if (!storedUser && (studentEmail || studentName)) {
        try {
          const guestSession = {
            id: Math.floor(1000 + Math.random() * 9000),
            name: studentName,
            studentId,
            email: studentEmail,
            role: 'student',
          };
          localStorage.setItem('biteahead_user', JSON.stringify(guestSession));
        } catch {}
      }

      // 2. Attempt sync with backend SQLite if running (non-blocking for Firebase Hosting)
      let backendOrder: Order | null = null;
      try {
        const res = await apiFetch<{ message: string; order: Order }>('/api/orders', {
          method: 'POST',
          body: JSON.stringify({
            items: cart.map(item => ({
              foodItemId: item.food.id,
              quantity: item.quantity,
            })),
            pickupSlot: effectiveSlot,
            notes: notes.trim(),
          }),
        });
        if (res?.order) {
          backendOrder = res.order;
        }
      } catch (apiErr: any) {
        console.log('ℹ️ Order saved to Cloud Firestore (operating in static Firebase mode):', apiErr?.message);
      }

      const finalOrder: Order = backendOrder || {
        id: Math.floor(1000 + Math.random() * 9000),
        orderId: generatedOrderId,
        studentId: 1,
        studentName,
        collegeStudentId: studentId,
        studentEmail,
        totalAmount: subtotal,
        pickupSlot: effectiveSlot,
        status: 'Placed',
        notes: notes.trim(),
        estimatedPrepTime: maxPrep,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        items: cart.map(item => ({
          id: item.food.id,
          orderId: 0,
          foodItemId: item.food.id,
          name: item.food.name,
          quantity: item.quantity,
          priceAtOrderTime: item.food.price,
        })),
      };

      // Clear cart on successful order
      clearCart();
      setNotes('');
      return finalOrder;
    } catch (err: any) {
      const msg = err.message || 'Failed to place order';
      setError(msg);
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        totalItemCount,
        subtotal,
        pickupSlots,
        selectedSlot,
        setSelectedSlot,
        notes,
        setNotes,
        placeOrder,
        isSubmitting,
        error,
        setError,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
