import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types.ts';
import { apiFetch, setStoredToken } from '../lib/api.ts';
import {
  auth,
  signInWithGoogle as firebaseSignInWithGoogle,
  signInWithEmail as firebaseSignInWithEmail,
  registerWithEmail as firebaseRegisterWithEmail,
  saveUserToFirestore,
  getUserFromFirestore,
  FirestoreUserData,
} from '../lib/firebase.ts';
import {
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  firebaseConnected: boolean;
  loading: boolean;
  loginWithEmail: (
    email: string,
    password: string,
    role?: 'student' | 'admin',
    adminTitle?: string
  ) => Promise<User>;
  registerWithEmail: (
    email: string,
    password: string,
    name: string,
    studentId?: string,
    role?: 'student' | 'admin',
    adminTitle?: string
  ) => Promise<User>;
  loginWithGoogle: (
    role?: 'student' | 'admin',
    adminTitle?: string,
    fallbackEmail?: string,
    fallbackName?: string
  ) => Promise<User>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  // Aliases for compatibility
  login: (identifier: string, password: string) => Promise<User>;
  register: (
    name: string,
    studentId: string,
    email: string,
    password: string,
    role?: 'student' | 'admin',
    adminTitle?: string
  ) => Promise<User>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('biteahead_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(() => auth.currentUser);
  const [firebaseConnected, setFirebaseConnected] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync a Firebase Auth user with Firestore and Express/SQLite backend
  const syncUserSession = async (
    fbUser: FirebaseUser,
    explicitRole?: 'student' | 'admin',
    explicitName?: string,
    explicitStudentId?: string,
    explicitAdminTitle?: string
  ): Promise<User> => {
    // 1. Fetch profile from Firestore with error isolation
    let firestoreProfile: Partial<FirestoreUserData> | null = null;
    try {
      firestoreProfile = await getUserFromFirestore(fbUser.uid);
    } catch (e: any) {
      console.warn('🔥 [Firestore Fetch Notice]:', e?.message || e);
    }

    const resolvedRole = explicitRole || firestoreProfile?.role || 'student';
    const resolvedName = explicitName || firestoreProfile?.name || fbUser.displayName || fbUser.email?.split('@')[0] || 'User';
    const resolvedStudentId = explicitStudentId || firestoreProfile?.studentId || (resolvedRole === 'admin' ? `ADMIN-${fbUser.uid.slice(0, 4).toUpperCase()}` : `STU-${fbUser.uid.slice(0, 6).toUpperCase()}`);
    const resolvedAdminTitle = explicitAdminTitle || firestoreProfile?.adminTitle || (resolvedRole === 'admin' ? 'Canteen Staff' : null);

    // 2. Always persist / update user and admin details in Firestore with latest login timestamp
    try {
      firestoreProfile = await saveUserToFirestore({
        uid: fbUser.uid,
        name: resolvedName,
        email: fbUser.email || firestoreProfile?.email || '',
        studentId: resolvedStudentId,
        role: resolvedRole,
        adminTitle: resolvedAdminTitle,
        photoURL: fbUser.photoURL || firestoreProfile?.photoURL || null,
        lastLoginAt: new Date().toISOString(),
        createdAt: firestoreProfile?.createdAt || new Date().toISOString(),
      });
    } catch (e: any) {
      console.warn('🔥 [Firestore Save Notice]:', e?.message || e);
    }

    const email = firestoreProfile?.email || fbUser.email || '';
    const name = firestoreProfile?.name || resolvedName;
    const studentId = firestoreProfile?.studentId || resolvedStudentId;
    const role = firestoreProfile?.role || resolvedRole;
    const adminTitle = firestoreProfile?.adminTitle || resolvedAdminTitle;

    // Immediately establish user session from Firebase Auth & Firestore
    const userObject: User = {
      id: Math.abs(fbUser.uid.split('').reduce((acc, char) => (acc << 5) - acc + char.charCodeAt(0), 0)) || 1,
      name,
      studentId: studentId || (role === 'admin' ? `ADMIN-${fbUser.uid.slice(0, 4).toUpperCase()}` : `STU-${fbUser.uid.slice(0, 6).toUpperCase()}`),
      email,
      role,
      adminTitle,
    };

    setUser(userObject);
    setFirebaseUser(fbUser);
    try {
      localStorage.setItem('biteahead_user', JSON.stringify(userObject));
    } catch {}

    // 3. Attempt synchronization with Express/SQLite backend if available (non-blocking for Firebase Hosting)
    try {
      const syncRes = await apiFetch<{ user: User; token: string }>('/api/auth/firebase-sync', {
        method: 'POST',
        body: JSON.stringify({
          uid: fbUser.uid,
          email,
          name,
          studentId: userObject.studentId,
          role,
          adminTitle,
        }),
      });

      if (syncRes?.token) {
        setStoredToken(syncRes.token);
      }
      if (syncRes?.user) {
        setUser(syncRes.user);
        try {
          localStorage.setItem('biteahead_user', JSON.stringify(syncRes.user));
        } catch {}
        return syncRes.user;
      }
    } catch (apiErr: any) {
      console.log('ℹ️ Running in Firebase Cloud Firestore mode:', apiErr?.message);
    }

    return userObject;
  };

  // Real-time listener for Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);

      if (fbUser) {
        console.log(`🔥 [Firebase Auth] Authenticated user: ${fbUser.email} (UID: ${fbUser.uid})`);
        try {
          await syncUserSession(fbUser);
        } catch (err: any) {
          console.error('🔥 [Auth Sync Error]:', err.message);
        }
      } else {
        console.log('🔥 [Firebase Auth] No active user.');
        setUser(null);
        setStoredToken(null);
        try {
          localStorage.removeItem('biteahead_user');
        } catch {}
        try {
          await apiFetch('/api/auth/logout', { method: 'POST' });
        } catch {}
      }

      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithEmail = async (
    email: string,
    password: string,
    role?: 'student' | 'admin',
    adminTitle?: string
  ): Promise<User> => {
    try {
      const fbUser = await firebaseSignInWithEmail(email, password);
      const syncedUser = await syncUserSession(fbUser, role, undefined, undefined, adminTitle);
      return syncedUser;
    } catch (fbErr: any) {
      // If user does not yet exist in the newly connected Firebase project, verify with canteen database
      if (
        fbErr?.code === 'auth/user-not-found' ||
        fbErr?.code === 'auth/invalid-credential' ||
        fbErr?.code === 'auth/invalid-login-credentials'
      ) {
        try {
          const localRes = await apiFetch<{ user: User; token: string }>('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ identifier: email, password }),
          });

          if (localRes && localRes.user) {
            // Auto-provision this user in the new Firebase project so future logins work with Firebase
            try {
              const newFbUser = await firebaseRegisterWithEmail(email, password, localRes.user.name);
              await saveUserToFirestore({
                uid: newFbUser.uid,
                name: localRes.user.name,
                email: localRes.user.email,
                studentId: localRes.user.studentId,
                role: localRes.user.role,
                adminTitle: localRes.user.adminTitle,
                lastLoginAt: new Date().toISOString(),
              });
              setFirebaseUser(newFbUser);
            } catch (autoErr) {
              console.warn('Firebase auto-provision notice:', autoErr);
            }

            setStoredToken(localRes.token);
            try {
              localStorage.setItem('biteahead_user', JSON.stringify(localRes.user));
            } catch {}
            setUser(localRes.user);
            return localRes.user;
          }
        } catch {
          throw fbErr;
        }
      }
      throw fbErr;
    }
  };

  const registerWithEmail = async (
    email: string,
    password: string,
    name: string,
    studentId?: string,
    role: 'student' | 'admin' = 'student',
    adminTitle?: string
  ): Promise<User> => {
    const fbUser = await firebaseRegisterWithEmail(email, password, name);
    // Explicitly write profile to Firestore
    try {
      await saveUserToFirestore({
        uid: fbUser.uid,
        name: name.trim(),
        email: email.trim().toLowerCase(),
        studentId: studentId?.trim().toUpperCase(),
        role,
        adminTitle: role === 'admin' ? (adminTitle?.trim() || 'Canteen Staff') : null,
      });
    } catch {}
    const syncedUser = await syncUserSession(fbUser, role, name, studentId, adminTitle);
    return syncedUser;
  };

  const loginWithGoogle = async (
    role: 'student' | 'admin' = 'student',
    adminTitle?: string,
    fallbackEmail?: string,
    fallbackName?: string
  ): Promise<User> => {
    const fbUser = await firebaseSignInWithGoogle(fallbackEmail, fallbackName);
    const syncedUser = await syncUserSession(fbUser, role, fbUser.displayName || fallbackName || undefined, undefined, adminTitle);
    return syncedUser;
  };

  const logout = async () => {
    try {
      await signOut(auth);
      console.log('🔥 [Firebase Auth] User signed out.');
    } catch (err: any) {
      console.error('Firebase sign out error:', err);
    }
    setStoredToken(null);
    try {
      localStorage.removeItem('biteahead_user');
    } catch {}
    setUser(null);
    setFirebaseUser(null);
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {}
  };

  const refreshUser = async () => {
    const current = auth.currentUser || firebaseUser;
    if (current) {
      await syncUserSession(current);
    }
  };

  // Compatibility aliases
  const login = async (identifier: string, password: string): Promise<User> => {
    return loginWithEmail(identifier, password);
  };

  const register = async (
    name: string,
    studentId: string,
    email: string,
    password: string,
    role: 'student' | 'admin' = 'student',
    adminTitle?: string
  ): Promise<User> => {
    return registerWithEmail(email, password, name, studentId, role, adminTitle);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        firebaseConnected,
        loading,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        logout,
        refreshUser,
        login,
        register,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
