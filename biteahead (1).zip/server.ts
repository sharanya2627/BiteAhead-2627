import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase } from './server/db.ts';
import { authMiddleware } from './server/auth.ts';
import authRoutes from './server/routes/auth.ts';
import foodRoutes from './server/routes/foods.ts';
import orderRoutes from './server/routes/orders.ts';
import studentRoutes from './server/routes/student.ts';
import adminRoutes from './server/routes/admin.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize SQLite database and seed if required
initDatabase();

const app = express();
const PORT = 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Common Express Middlewares
app.use(express.json());
app.use(cookieParser());
app.use(authMiddleware);

// API Route Mounts
app.use('/api/auth', authRoutes);
app.use('/api/foods', foodRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/admin', adminRoutes);

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    app: 'BiteAhead Canteen Pre-order System',
    timestamp: new Date().toISOString(),
  });
});

// Vite Middleware for Development / Static Serve for Production
async function setupFrontend() {
  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Vite development middleware mounted successfully.');
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
    console.log(`Serving static production build from ${distPath}`);
  }
}

setupFrontend().then(() => {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BiteAhead Server running at http://0.0.0.0:${PORT}`);
  });
});
